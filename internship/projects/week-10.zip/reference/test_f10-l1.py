def response(body, status=200):
    return {"status":status,"body":body}

assert response([])=={"status":200,"body":[]}
assert response({"id":1},201)["status"]==201
assert response({"error":"missing"},404)["body"]=={"error":"missing"}
print("Checks passed")
