def response(body, status=200):
    return {"status":status,"body":body}
