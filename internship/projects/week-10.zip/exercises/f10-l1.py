def response(body, status=200):
    pass
