def mean(values):
    if not values:
        return None
    return sum(values) / len(values)

assert mean([2,4,6])==4
assert mean([]) is None
assert mean([-2,2])==0
print("Checks passed")
