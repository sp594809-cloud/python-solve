def welcome():
    return "Ready to learn"

assert welcome()=="Ready to learn"
assert welcome()==welcome()
print("Checks passed")
