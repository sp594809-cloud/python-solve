def welcome():
    return "Ready to learn"
