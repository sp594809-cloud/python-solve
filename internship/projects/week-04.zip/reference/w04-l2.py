def budget(income, expenses):
    total = sum(expenses)
    remaining = income - total
    return {"total": total, "remaining": remaining, "overspent": remaining < 0}
