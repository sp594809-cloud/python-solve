def total_cost(prices):
    total = 0
    for price in prices:
        total += price
    return total
