def greet(name, prefix="Hello"):
    return f"{prefix} {name}"

assert greet("Asha")=="Hello Asha"
assert greet("Krish",prefix="Hi")=="Hi Krish"
assert greet("Sam","Welcome")=="Welcome Sam"
print("Checks passed")
