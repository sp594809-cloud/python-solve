def budget(income, expenses):
    total = sum(expenses)
    remaining = income - total
    return {"total": total, "remaining": remaining, "overspent": remaining < 0}

assert budget(100,[20,30])=={"total":50,"remaining":50,"overspent":False}
assert budget(50,[50])["overspent"] is False
assert budget(20,[30])["remaining"]==-10 and budget(20,[30])["overspent"] is True
print("Checks passed")
