def discounted(price):
    final_price = price * 0.9
    return final_price

assert discounted(100)==90
assert discounted(0)==0
assert "final_price" not in globals()
print("Checks passed")
