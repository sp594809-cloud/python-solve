def add(a, b):
    return a + b

assert add(2,3)==5
assert add(2,3)*2==10
assert add(-2,1)==-1
print("Checks passed")
