def discounted(price):
    final_price = price * 0.9
    return final_price
