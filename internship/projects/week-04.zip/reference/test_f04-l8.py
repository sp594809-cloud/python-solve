def is_even(number):
    return number % 2 == 0

assert is_even(8) is True
assert is_even(7) is False
assert is_even(0) is True and is_even(-4) is True
print("Checks passed")
