def last(items):
    if not items:
        return None
    return items[-1]

assert last(["a","b"])=="b"
assert last([7])==7
assert last([]) is None
print("Checks passed")
