def total_cost(prices):
    total = 0
    for price in prices:
        total += price
    return total

assert total_cost([10,20,5])==35
assert total_cost([])==0
assert total_cost([2])==2 and total_cost([3])==3
print("Checks passed")
