def double(number):
    return number * 2

assert double(5)==10
assert double(0)==0
assert double(-3)==-6
print("Checks passed")
