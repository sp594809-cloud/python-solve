def sum_to(n):
    return sum(range(1, n + 1))

assert sum_to(1)==1
assert sum_to(5)==15
assert sum_to(0)==0
print("Checks passed")
