def total(expenses):return sum(expenses)
def budget(income,expenses):
    spent=total(expenses)
    return {"spent":spent,"remaining":income-spent,"overspent":spent>income}
def display(summary):return f"Remaining: {summary['remaining']} | Overspent: {summary['overspent']}"
if __name__=="__main__":print(display(budget(200,[30,70])))
