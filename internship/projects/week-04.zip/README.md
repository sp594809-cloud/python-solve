# Week 4: Budget planner

Break a larger problem into small functions.

## Your assignment
- Separate input, calculation and output.
- Write a monthly budget summary.
- Fix one deliberate bug and explain the change.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Functions with one responsibility
Return a mean, or None for empty input.

A function should have one clearly stated job. Distinguish no data from a real mean of zero. Returning None makes that difference explicit and lets the caller choose a message.

Try exercises/w04-l1.py before reading reference/w04-l1.py.

## Compose smaller functions
Return a budget summary with total, remaining and overspent.

Separate totals from presentation. A dictionary gives names to results so callers do not have to remember tuple positions. Overspent means remaining is negative, not zero.

Try exercises/w04-l2.py before reading reference/w04-l2.py.

## Fix an off-by-one bug
Correct the function so it sums the integers from 1 through n, including n.

range stops before its second argument. An off-by-one bug often survives one example and appears at small boundaries. Try n=1 and n=0 before assuming a loop is correct.

Try exercises/w04-l3.py before reading reference/w04-l3.py.
