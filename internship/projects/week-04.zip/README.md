# Week 4: Budget planner

Turn scripts into reusable functions and check boundary cases.

## Your assignment
- Separate input, calculation and display.
- Write a budget summary with small functions.
- Explain one bug and keep a regression test.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Define and call a function
Define welcome() returning "Ready to learn".

A function gives a name to a reusable piece of work. def defines the function; it does not run the body. A call uses the name followed by parentheses.

return sends a value back to the caller. In this exercise the checker calls your function, so you do not need input prompts.

Try exercises/f04-l1.py before reading reference/f04-l1.py.

## Parameters carry inputs
Define double(number) returning twice the given number.

A parameter is a name inside a function for a supplied input. An argument is the value supplied at a call. The same function can work with many arguments.

Avoid hard-coding the example answer. Your function should calculate from its parameter so it works for values the lesson did not show.

Try exercises/f04-l2.py before reading reference/f04-l2.py.

## Returning is different from printing
Define add(a,b) returning a+b.

print is useful for people reading a screen. return is useful for other code that needs a result. A function that only prints usually returns None.

Keep calculations separate from display. A caller can print a returned result, store it, or use it in another calculation.

Try exercises/f04-l3.py before reading reference/f04-l3.py.

## Defaults and keyword arguments
Define greet(name, prefix="Hello") returning prefix, a space and name.

A default argument is used when a caller omits that input. Keyword arguments identify a parameter by name. They make calls with optional settings easier to read.

Put required parameters before defaulted ones. Use simple immutable defaults for now; mutable list defaults are shared between calls and need extra care.

Try exercises/f04-l4.py before reading reference/f04-l4.py.

## Local variables keep work separate
Define discounted(price) using a local final_price equal to 90% of price and returning it.

A variable assigned inside a function is normally local to that call. It helps organize intermediate work without changing unrelated values outside.

Prefer passing inputs and returning outputs over changing global state. That makes functions easier to test and combine.

Try exercises/f04-l5.py before reading reference/f04-l5.py.

## Combine a loop and a function
Define total_cost(prices) returning their sum, with 0 for an empty list.

A function can contain the loop you already know. Initialize the accumulator inside the function so each call starts fresh.

Place return after the loop when you want to process every item. An indented return inside the loop exits on the first iteration.

Try exercises/f04-l6.py before reading reference/f04-l6.py.

## Debug using expected and actual values
Fix last(items) so it returns the last item or None for an empty list.

Debugging starts with a small example and an expected result. Run the code, compare actual with expected, and locate the earliest wrong assumption.

A boundary case such as an empty list often exposes a hidden assumption. Fix the cause, then rerun both the failing case and a normal case.

Try exercises/f04-l7.py before reading reference/f04-l7.py.

## Write your first assertions
Define is_even(number), returning a boolean for divisibility by 2.

An assertion states something your program expects to be true. If the expression is false, Python raises AssertionError. That is useful feedback during development.

Use normal inputs, boundary values and counterexamples. A test that only repeats the example leaves many mistakes undetected.

Try exercises/f04-l8.py before reading reference/f04-l8.py.

## Functions with one responsibility
Return a mean, or None for empty input.

A function should have one clearly stated job. Distinguish no data from a real mean of zero. Returning None makes that difference explicit and lets the caller choose a message.

Try exercises/w04-l1.py before reading reference/w04-l1.py.

## Compose smaller functions
Return a budget summary with total, remaining and overspent.

Separate totals from presentation. A dictionary gives names to results so callers do not have to remember tuple positions. Overspent means remaining is negative, not zero.

Try exercises/w04-l2.py before reading reference/w04-l2.py.

## Fix an off-by-one bug
Correct the function so it sums the integers from 1 through n, including n.

range stops before its second argument. An off-by-one bug often survives one example and appears at small boundaries. Try n=1 and n=0 before assuming a loop is correct.

Try exercises/w04-l3.py before reading reference/w04-l3.py.

### Define and call a function — walkthrough
- def creates label.
- return is indented inside its body.
- label() runs the body; print displays the returned text.

Expected output: Study time

Common mistake: Writing welcome without parentheses refers to the function itself. welcome() calls it.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Parameters carry inputs — walkthrough
- value receives four during this call.
- The multiplication uses that input.

Expected output: 12

Common mistake: Returning 10 passes the example but fails other inputs. Use the parameter.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Returning is different from printing — walkthrough
- square returns nine.
- The caller stores nine and adds one.

Expected output: 10

Common mistake: If you see the correct number printed but the check says None, inspect whether you used return.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Defaults and keyword arguments — walkthrough
- The first call uses the default tax zero.
- The second explicitly supplies tax two.

Expected output: 10
12

Common mistake: A default is not used when you explicitly pass another value. Distinguish omitted from supplied arguments.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Local variables keep work separate — walkthrough
- remaining belongs to the function call.
- The returned value crosses the function boundary.

Expected output: 8

Common mistake: A local variable is not automatically available after the call. Use the returned value.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Combine a loop and a function — walkthrough
- The function starts its own counter.
- The loop updates it for both items.
- return aligns with for, so it runs after the loop.

Expected output: 2

Common mistake: A return in the first loop iteration skips later prices. Check its indentation.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Debug using expected and actual values — walkthrough
- Negative index -1 selects the final item.
- An empty list has no final item, so it needs a separate decision.

Expected output: b

Common mistake: Catching every exception would hide unrelated mistakes. Handle the known empty-input condition directly.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Write your first assertions — walkthrough
- The first assertion checks a positive case.
- The second checks the boundary zero.

Expected output: Two checks passed

Common mistake: Do not return the strings "True" and "False". Tests need boolean values.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.
