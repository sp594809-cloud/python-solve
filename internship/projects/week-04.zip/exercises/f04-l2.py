def double(number):
    pass
