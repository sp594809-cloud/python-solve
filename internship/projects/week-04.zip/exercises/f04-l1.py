def welcome():
    # Return the requested text.
    pass
