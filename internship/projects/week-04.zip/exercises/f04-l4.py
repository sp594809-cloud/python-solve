def greet(name, prefix="Hello"):
    pass
