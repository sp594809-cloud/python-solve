def total_cost(prices):
    total = 0
    # Add the prices, then return total.
