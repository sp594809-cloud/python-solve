def sum_to(n):
    return sum(range(1, n))  # Bug: misses the last value
