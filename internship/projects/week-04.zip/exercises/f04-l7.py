def last(items):
    return items[0]
