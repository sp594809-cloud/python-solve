def discounted(price):
    pass
