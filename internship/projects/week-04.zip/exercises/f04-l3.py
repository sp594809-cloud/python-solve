def add(a, b):
    print(a + b)  # Change this line.
