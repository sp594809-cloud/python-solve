def budget(income, expenses):
    # TODO: implement the task. Keep the function name and parameters.
    pass
