def ready(checks):
    return all(checks.get(key) is True for key in ("tests","readme","no_secrets"))
