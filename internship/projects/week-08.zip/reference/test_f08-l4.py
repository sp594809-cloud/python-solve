def average(values):
    if not values:
        return None
    return sum(values)/len(values)

assert average([2,4])==3
assert average([]) is None
assert average([-1,1])==0
print("Checks passed")
