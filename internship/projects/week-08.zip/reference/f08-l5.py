def audit(action, item_id):
    return {"action":action,"item_id":item_id,"status":"ok"}
