def countdown(n):
    while n>0:
        yield n
        n-=1

assert list(countdown(3))==[3,2,1]
assert list(countdown(0))==[]
g=countdown(2);assert iter(g) is g and next(g)==2
print("Checks passed")
