def audit(action, item_id):
    return {"action":action,"item_id":item_id,"status":"ok"}

assert audit("save",7)["action"]=="save"
assert audit("delete",0)["item_id"]==0
assert set(audit("read",1))=={"action","item_id","status"}
print("Checks passed")
