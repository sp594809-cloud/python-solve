def squares(numbers):
    return [n*n for n in numbers]

assert squares([2,-3,0])==[4,9,0]
assert squares([])==[]
a=[2];squares(a);assert a==[2]
print("Checks passed")
