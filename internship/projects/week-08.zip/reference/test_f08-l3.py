def join_name(first: str, last: str) -> str:
    return first.strip()+" "+last.strip()

assert join_name("Asha","Patel")=="Asha Patel"
assert join_name(" Asha "," Patel ")=="Asha Patel"
assert isinstance(join_name("A","B"),str)
print("Checks passed")
