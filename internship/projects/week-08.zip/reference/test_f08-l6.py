def ready(checks):
    return all(checks.get(key) is True for key in ("tests","readme","no_secrets"))

assert ready({"tests":True,"readme":True,"no_secrets":True}) is True
assert ready({"tests":True}) is False
assert ready({"tests":"yes","readme":True,"no_secrets":True}) is False
print("Checks passed")
