def join_name(first: str, last: str) -> str:
    return first.strip()+" "+last.strip()
