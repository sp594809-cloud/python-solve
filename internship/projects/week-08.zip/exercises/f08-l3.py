def join_name(first: str, last: str) -> str:
    pass
