def countdown(n):
    # Use yield in a terminating loop.
    return iter([])
