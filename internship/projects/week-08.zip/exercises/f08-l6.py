def ready(checks):
    pass
