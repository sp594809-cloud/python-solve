def squares(numbers):
    pass
