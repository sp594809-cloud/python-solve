# Week 8: Tested Python package

Write code that another person can run and review.

## Your assignment
- Create a README with setup and examples.
- Add passing tests and a regression test for a fixed bug.
- Make at least three meaningful Git commits locally.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py "AI ai Python"
```

Run python -m unittest. Start local history with git init, git add ., git commit -m "Add working summary". Make a change and test before another commit. GitHub upload requires your own account.

## List comprehensions after you understand loops
Define squares(numbers), returning a new list of squared values.

A list comprehension is a compact way to build a new list from an iterable. Read it as: calculate this expression for every item.

Start by writing the ordinary loop if the expression is confusing. A shorter program is not automatically a clearer one. Avoid deeply nested comprehensions when a few named steps would explain the logic.

Try exercises/f08-l1.py before reading reference/f08-l1.py.

## Generators produce one result at a time
Define countdown(n) yielding n down to 1; nonpositive n yields nothing.

A generator uses yield to produce a value and pause. The next iteration resumes from that point. It avoids creating a full list when you only need one item at a time.

Generators are consumed as you iterate. To repeat the sequence, create a new generator. They are useful for processing a stream or large file without keeping every result in memory.

Try exercises/f08-l2.py before reading reference/f08-l2.py.

## Type hints document a contract
Define join_name(first: str,last: str) -> str returning stripped names separated by one space.

Type hints communicate expected types to people and checking tools. Python normally does not enforce these hints at runtime. You still need validation at external boundaries.

Use hints to make an interface easier to understand. Prefer a small, honest contract over annotations that claim more than your implementation guarantees.

Try exercises/f08-l3.py before reading reference/f08-l3.py.

## Regression tests protect a fixed bug
Fix average(values), returning None for empty input and the arithmetic mean otherwise.

A regression test captures a bug so it does not quietly return later. First produce the smallest failing case. Fix the code, then keep that case alongside normal examples.

Do not write a test that simply repeats your implementation. State an expected result you can calculate independently. For [2,4], the mean should be three.

Try exercises/f08-l4.py before reading reference/f08-l4.py.

## Use structured information for debugging
Define audit(action,item_id), returning an event dictionary with those fields and status="ok".

Useful logs describe events with consistent fields. A developer can then connect a request, action and result. Printing an unexplained number is much less helpful.

This exercise builds an event record rather than configuring logging. In a project, use Python’s logging module and choose an appropriate level. Never put passwords or private messages in routine logs.

Try exercises/f08-l5.py before reading reference/f08-l5.py.

## Review code before sharing it
Define ready(checks) that is True only when tests, readme and no_secrets are explicitly True.

A code review asks whether the change solves the stated problem, is understandable, and has evidence. A README should let someone start from a clean folder and reproduce your result.

A checklist is a reminder, not an automated security or quality guarantee. Let another person run your project and ask for one small change you did not prepare for.

Try exercises/f08-l6.py before reading reference/f08-l6.py.

## Tests that reveal a bug
Return whether a string is a palindrome after removing spaces and normalizing case.

Test ordinary inputs and counterexamples. A result that is always True passes positive examples but fails a negative case. State which punctuation rules apply; here only spaces and case are ignored.

Try exercises/w08-l1.py before reading reference/w08-l1.py.

## Debug from a failing assertion
Fix the function so it never changes its caller’s list.

Assignment copies a reference, not the list. If a helper must preserve input, copy before mutation or build a new result. Tests should inspect the original after the call.

Try exercises/w08-l2.py before reading reference/w08-l2.py.

## Package a useful command
Summarize words with total and unique counts.

A package should expose a small, predictable interface. Keep the calculation separate from a CLI so tests do not need to interact with input prompts. The README should state the normalization rules.

Try exercises/w08-l3.py before reading reference/w08-l3.py.

### List comprehensions after you understand loops — walkthrough
- The expression n*2 produces each new item.
- The for part supplies values of n.

Expected output: [2, 4, 6]

Common mistake: A comprehension used only for side effects makes intent harder to read. Use a loop for actions.

Watch: [Et Cetera](https://www.youtube.com/watch?v=6pgodt1mezg) — Harvard CS50 · David Malan (English). Use the type hints, comprehensions and generators sections after Week 7. Pause to rewrite each example.

### Generators produce one result at a time — walkthrough
- The function returns a generator when called.
- list consumes its yielded values for display.

Expected output: [10, 20]

Common mistake: return ends the generator; yield pauses it. Replacing yield with return loses the sequence.

Watch: [Et Cetera](https://www.youtube.com/watch?v=6pgodt1mezg) — Harvard CS50 · David Malan (English). Use the type hints, comprehensions and generators sections after Week 7. Pause to rewrite each example.

### Type hints document a contract — walkthrough
- The annotation describes the intended input.
- The body still performs ordinary Python arithmetic.

Expected output: 5

Common mistake: Annotations alone do not reject a number supplied as first. Decide where runtime validation belongs.

Watch: [Et Cetera](https://www.youtube.com/watch?v=6pgodt1mezg) — Harvard CS50 · David Malan (English). Use the type hints, comprehensions and generators sections after Week 7. Pause to rewrite each example.

### Regression tests protect a fixed bug — walkthrough
- The expected result is reasoned about separately.
- The assertion compares the implementation’s result with it.

Expected output: Mean checked

Common mistake: Changing the test to accept the broken answer does not fix the bug. Recheck the intended contract.

Watch: [Unit Tests](https://www.youtube.com/watch?v=tIrcxwLqzjQ) — Harvard CS50 · David Malan (English). Observe a failing test, repair the code and rerun the suite.

### Use structured information for debugging — walkthrough
- The field names explain the values.
- A stable structure is easier to search and test.

Expected output: save ok

Common mistake: A log entry is not proof that an operation succeeded. Write it after checking the actual result.

Watch: [Dictionaries: Working with Key-Value Pairs](https://www.youtube.com/watch?v=daefaLgNkw0) — Corey Schafer (English). Practise reading, updating and safely looking up dictionary values.

### Review code before sharing it — walkthrough
- A missing requirement should not count as complete.
- Explicit booleans make this small contract predictable.

Expected output: True

Common mistake: A self-reported checklist cannot replace an independent review. Show the evidence behind each check.

Watch: [Git](https://www.youtube.com/watch?v=NcoBAfJ6l2Q) — Harvard CS50 · Brian Yu (English). Practise status, commits and branches in a disposable learning repository.

Watch: [Unit Tests](https://www.youtube.com/watch?v=tIrcxwLqzjQ) — Harvard CS50 · David Malan (English). Observe a failing test, repair the code and rerun the suite.

Watch: [Unit Tests](https://www.youtube.com/watch?v=tIrcxwLqzjQ) — Harvard CS50 · David Malan (English). Observe a failing test, repair the code and rerun the suite.

Watch: [Unit Tests](https://www.youtube.com/watch?v=tIrcxwLqzjQ) — Harvard CS50 · David Malan (English). Observe a failing test, repair the code and rerun the suite.
