# Create both requested variables.
