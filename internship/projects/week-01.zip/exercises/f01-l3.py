# Explain your target here.
study_minutes = 0
print(study_minutes)
