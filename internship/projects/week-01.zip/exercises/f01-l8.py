quantity_text = "3"
# Make quantity and total.
