points = 5
# Add three, then subtract one.
