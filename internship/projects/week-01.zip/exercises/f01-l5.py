# Create the four values named in the task.
