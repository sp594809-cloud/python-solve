price = 40
quantity = 3
# Calculate total and change.
