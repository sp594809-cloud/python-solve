# Week 1: Study profile and stationery bill

Read and write small scripts using print, variables, types and arithmetic.

## Your assignment
- Print a study profile using named variables.
- Calculate a stationery bill and change.
- Change the quantities and explain the new result.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Your first line of Python
Print I am learning Python on one line.

A program is a set of instructions. Python reads these instructions and performs them. In this lesson you only need one instruction: print.

Text must go between matching quotation marks. The parentheses tell print which value to show. The output area is where you see the result; writing code in the editor alone does not run it.

Try exercises/f01-l1.py before reading reference/f01-l1.py.

## Read code from top to bottom
Print Ready and then Go on separate lines.

Python normally runs one statement after another. A statement is one instruction. The order you write matters: printing a title after the answer produces a different screen.

Each print call normally adds a new line. Start with two short statements before trying a large program.

Try exercises/f01-l2.py before reading reference/f01-l2.py.

## Comments explain a decision
Set study_minutes to 20 and print its value. Add a comment explaining the target.

A comment begins with # outside a string. Python ignores the comment when running the program. Comments help a person understand why a decision was made.

The example also introduces assignment: the name minutes refers to the number 15. Reading print(minutes) asks Python for that value. You will practise variables next.

Try exercises/f01-l3.py before reading reference/f01-l3.py.

## Variables are names for values
Create student_name with the text Asha and semesters_done with the number 1.

A variable lets you name a value and use it again. Choose names that tell a reader what the value means. student_name is more useful than x when storing a name.

Use = to assign. It does not mean a permanent mathematical equality. A later assignment can attach a different value to the same name.

Try exercises/f01-l4.py before reading reference/f01-l4.py.

## Four useful data types
Create course="Python", days=4, hours=1.5 and enrolled=True.

The type of a value describes what operations make sense. str is text, int is a whole number, float supports decimals, and bool represents True or False.

The characters "4" make a string. The number 4 is an integer. They look similar on screen but behave differently when you add them. You do not need to memorize every Python type today.

Try exercises/f01-l5.py before reading reference/f01-l5.py.

## Calculate with numbers
Store 3 notebooks at ₹40 each in total, and the change from ₹200 in change.

Use +, -, * and / for ordinary arithmetic. Python uses * for multiplication. Parentheses group an operation you want to do first.

Store an intermediate result under a useful name so you can inspect it. A calculation is easier to debug when you can check the quantity, price and total separately.

Try exercises/f01-l6.py before reading reference/f01-l6.py.

## Update a value and trace it
Start points at 5, add 3, then subtract 1. Leave the result in points.

An assignment calculates the right side first. In points = points + 2, Python reads the old points, adds two, then stores the new value.

The shorter form points += 2 performs this update for a number. Trace each intermediate value on paper instead of guessing the final result.

Try exercises/f01-l7.py before reading reference/f01-l7.py.

## Convert text into a number
Convert quantity_text="3" to an integer and calculate a ₹25-per-item total.

User input and data from text files often arrive as strings. Convert numeric text before doing arithmetic. int("3") produces the integer 3; float("3.5") handles decimals.

Conversion can fail if the text is not a number. We will handle that with exceptions later. For now, use the supplied valid text.

Try exercises/f01-l8.py before reading reference/f01-l8.py.

## Expressions and return values
Return the total price after a percentage discount.

Python evaluates arithmetic in an order. Parentheses make that order clear. Return sends a value to the caller; printing only displays it. A 10% discount keeps 90% of the original amount.

Try exercises/w01-l1.py before reading reference/w01-l1.py.

## Types and conversion
Convert numeric text into a Celsius temperature.

Input text is a string even when it looks like a number. float accepts decimals. Converting early separates input handling from arithmetic. Fahrenheit to Celsius is (F - 32) times 5/9.

Try exercises/w01-l2.py before reading reference/w01-l2.py.

## Text and readable output
Build a greeting from a name and integer score.

strip removes surrounding whitespace. An f-string inserts values into text without manual concatenation. Keep punctuation and spaces intentional because output is a user interface.

Try exercises/w01-l3.py before reading reference/w01-l3.py.

### Your first line of Python — walkthrough
- print is the instruction that displays a value.
- The quoted words are text, also called a string.
- Run the line and compare the output with the expected output below.

Expected output: My first notebook

Common mistake: Print with a capital P is a different name. Python names are case-sensitive. Use lowercase print.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Read code from top to bottom — walkthrough
- The first print finishes before the second starts.
- The newline comes from print; you do not need to press Enter inside the quotes.

Expected output: Step A
Step B

Common mistake: Do not split a quoted string over two source lines accidentally. Use two complete print calls.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Comments explain a decision — walkthrough
- The comment is for the reader.
- The equals sign assigns the value on its right to the name on its left.
- print(minutes) reads the assigned number.

Expected output: 15

Common mistake: A # inside quotation marks is part of the text. A # outside them starts a comment.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Variables are names for values — walkthrough
- city refers to text; visits refers to a number.
- The comma in print displays both values with a space.

Expected output: Ahmedabad 2

Common mistake: student-name is interpreted as subtraction. Use student_name for a name containing two words.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Four useful data types — walkthrough
- type(value) inspects its type.
- The displayed class name tells you whether the value is text or an integer.

Expected output: <class 'str'>
<class 'int'>

Common mistake: "True" is text; True is a boolean. Do not decide a value’s type only by how it prints.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Calculate with numbers — walkthrough
- Read price and quantity first.
- Multiplication produces the bill.
- Changing quantity recalculates the bill when you rerun the cell.

Expected output: 50

Common mistake: Writing 3(40) does not mean multiplication in Python. Use 3 * 40.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Update a value and trace it — walkthrough
- After line one points is 10.
- After line two it is 12.
- After line three it is 8.

Expected output: 8

Common mistake: points =+ 3 assigns positive 3. The update operator is += in that order.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Convert text into a number — walkthrough
- age_text remains a string.
- int returns a new numeric value.
- Adding one is now arithmetic, not text joining.

Expected output: 19

Common mistake: int("3.5") fails because that text is not an integer representation. Use float when the input allows decimals.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.
