course = "Python"
days = 4
hours = 1.5
enrolled = True
