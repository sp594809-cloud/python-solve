print("Ready")
print("Go")


print("Checks passed")
