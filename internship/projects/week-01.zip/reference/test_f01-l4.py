student_name = "Asha"
semesters_done = 1

assert student_name == "Asha"
assert semesters_done == 1 and type(semesters_done) is int
print("Checks passed")
