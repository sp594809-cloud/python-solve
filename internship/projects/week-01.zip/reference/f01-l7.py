points = 5
points += 3
points -= 1
