points = 5
points += 3
points -= 1

assert points==7
print("Checks passed")
