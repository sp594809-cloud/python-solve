price = 40
quantity = 3
total = price * quantity
change = 200 - total
