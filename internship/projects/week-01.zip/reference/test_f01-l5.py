course = "Python"
days = 4
hours = 1.5
enrolled = True

assert course=="Python" and type(days) is int and days==4
assert type(hours) is float and hours==1.5 and enrolled is True
print("Checks passed")
