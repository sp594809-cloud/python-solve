student_name = "Asha"
semesters_done = 1
