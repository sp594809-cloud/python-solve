quantity_text = "3"
quantity = int(quantity_text)
total = quantity * 25

assert quantity==3 and type(quantity) is int
assert total==75
print("Checks passed")
