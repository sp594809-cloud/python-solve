print("I am learning Python")


print("Checks passed")
