print("Ready")
print("Go")
