# Twenty focused minutes is my starting target.
study_minutes = 20
print(study_minutes)
