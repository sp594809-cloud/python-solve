price = 40
quantity = 3
total = price * quantity
change = 200 - total

assert total==120
assert change==80
print("Checks passed")
