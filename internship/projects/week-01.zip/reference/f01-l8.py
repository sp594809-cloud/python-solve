quantity_text = "3"
quantity = int(quantity_text)
total = quantity * 25
