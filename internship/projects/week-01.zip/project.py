name = "Asha"
minutes = 20
price = 25
quantity = 3
total = price * quantity
change = 100 - total
print(f"{name}: {minutes} minutes of Python")
print("Bill:", total, "Change:", change)
