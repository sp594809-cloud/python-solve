# Week 13: Dataset report

Inspect features, labels and train/test separation before fitting a model.

## Your assignment
- Create a documented synthetic dataset.
- Report missing data and class counts.
- Split before fitting preprocessing and explain leakage.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```
Install requirements first: python -m pip install -r requirements.txt. Synthetic data is deliberately small; replace it with documented, permissioned data before making performance claims.

## Features, labels and a baseline
Define majority(labels), returning the most frequent label; break ties alphabetically and return None for no labels.

A feature is information a model can use as input. A label is the target you want it to predict. Training examples connect inputs with known labels.

Before training, compare with a simple baseline. Always predicting the most common label can already score highly on an imbalanced dataset. A more complex model must justify its added complexity.

Try exercises/f13-l1.py before reading reference/f13-l1.py.

## Inspect missing values before modelling
Return missing and total counts for a sequence; None is the missing marker.

Before training, inspect the dataset and document units and labels. Missing data is different from zero. This course uses small synthetic data for learning; it cannot establish real-world model quality.

Try exercises/w13-l1.py before reading reference/w13-l1.py.

## Split before fitting preprocessing
Split ordered records at an index without overlapping or modifying the input.

Separate training and test data before fitting a scaler or vocabulary. Random or stratified splitting is usually preferable for model evaluation; this deterministic split is a small exercise in keeping sets separate. Time-series data needs chronological splitting.

Try exercises/w13-l2.py before reading reference/w13-l2.py.

## Fit normalization on training data
Scale a value using training minimum and maximum. Return zero for a constant training range.

Fit statistics using training data only. A test value can fall outside 0–1; clipping would be an extra modelling decision. Fitting on the test set leaks information into evaluation.

Try exercises/w13-l3.py before reading reference/w13-l3.py.

### Features, labels and a baseline — walkthrough
- There are two billing examples.
- A majority baseline would always choose billing for this training set.

Expected output: 2

Common mistake: Training accuracy alone does not show how a model behaves on unseen examples. Hold out data before fitting.

Watch: [A Gentle Introduction to Machine Learning](https://www.youtube.com/watch?v=Gv9_4yMHFhI) — StatQuest · Josh Starmer (English). Learn the training/test distinction before fitting the course model.

Watch: [A Gentle Introduction to Machine Learning](https://www.youtube.com/watch?v=Gv9_4yMHFhI) — StatQuest · Josh Starmer (English). Learn the training/test distinction before fitting the course model.

Watch: [Machine Learning Fundamentals: Cross Validation](https://www.youtube.com/watch?v=fSytzGwwBVw) — StatQuest · Josh Starmer (English). Understand why one train/test score is insufficient and how validation helps model selection.

Watch: [Machine Learning Fundamentals: Cross Validation](https://www.youtube.com/watch?v=fSytzGwwBVw) — StatQuest · Josh Starmer (English). Understand why one train/test score is insufficient and how validation helps model selection.
