def missing_report(values):
    # TODO: implement the task. Keep the function name and parameters.
    pass
