def scale(value, training_values):
    # TODO: implement the task. Keep the function name and parameters.
    pass
