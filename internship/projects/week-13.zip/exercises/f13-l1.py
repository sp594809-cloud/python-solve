def majority(labels):
    pass
