def split_records(records, train_size):
    # TODO: implement the task. Keep the function name and parameters.
    pass
