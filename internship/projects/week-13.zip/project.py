from collections import Counter
from sklearn.model_selection import train_test_split
records=[{"hours":i,"passed":int(i>=4)} for i in range(1,9)] # synthetic, not students
train,test=train_test_split(records,test_size=0.25,random_state=42,stratify=[r["passed"] for r in records])
print("Synthetic records:",len(records));print("Missing hours:",sum(r["hours"] is None for r in records))
print("Class counts:",dict(Counter(r["passed"] for r in records)))
low=min(r["hours"] for r in train);high=max(r["hours"] for r in train)
print("Training min/max:",low,high);print("Scaled test:",[(r["hours"]-low)/(high-low) for r in test])
