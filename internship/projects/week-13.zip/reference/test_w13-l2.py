def split_records(records, train_size):
    if not 0 < train_size < len(records):
        raise ValueError("both sets must be nonempty")
    return records[:train_size], records[train_size:]

a,b=split_records([1,2,3,4],2);assert a==[1,2] and b==[3,4]
r=[1,2,3];split_records(r,1);assert r==[1,2,3]
try:
 split_records([1,2],2)
except ValueError:
 pass
else:
 raise AssertionError("Expected ValueError")
print("Checks passed")
