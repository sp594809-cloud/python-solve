def scale(value, training_values):
    low, high = min(training_values), max(training_values)
    return 0.0 if high == low else (value-low)/(high-low)
