def majority(labels):
    if not labels: return None
    counts={label:labels.count(label) for label in set(labels)}
    return sorted(counts,key=lambda label:(-counts[label],label))[0]
