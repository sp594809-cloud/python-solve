def scale(value, training_values):
    low, high = min(training_values), max(training_values)
    return 0.0 if high == low else (value-low)/(high-low)

assert scale(5,[0,10])==0.5
assert scale(20,[0,10])==2
assert scale(5,[5,5])==0
print("Checks passed")
