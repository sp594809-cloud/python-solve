def missing_report(values):
    return {"missing":sum(value is None for value in values), "total":len(values)}

assert missing_report([0,None,2,None])=={"missing":2,"total":4}
assert missing_report([])=={"missing":0,"total":0}
assert missing_report([0,0])["missing"]==0
print("Checks passed")
