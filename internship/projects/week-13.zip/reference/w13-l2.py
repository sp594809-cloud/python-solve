def split_records(records, train_size):
    if not 0 < train_size < len(records):
        raise ValueError("both sets must be nonempty")
    return records[:train_size], records[train_size:]
