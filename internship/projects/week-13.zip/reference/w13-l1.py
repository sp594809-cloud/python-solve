def missing_report(values):
    return {"missing":sum(value is None for value in values), "total":len(values)}
