import json
def read_name(text):
    pass
