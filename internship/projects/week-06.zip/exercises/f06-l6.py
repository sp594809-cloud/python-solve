def valid_record(record):
    pass
