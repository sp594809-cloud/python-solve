def json_copy(record):
    # TODO: implement the task. Keep the function name and parameters.
    pass
