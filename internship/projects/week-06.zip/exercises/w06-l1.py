def parse_scores(text):
    # TODO: implement the task. Keep the function name and parameters.
    pass
