import sqlite3
def stored_count(names):
    pass
