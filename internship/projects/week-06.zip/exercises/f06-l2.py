import csv, io
def csv_names(text):
    pass
