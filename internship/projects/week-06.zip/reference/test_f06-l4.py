setup_steps = ["python -m venv .venv", "python -m pip install -r requirements.txt", "python -m unittest"]

assert setup_steps[0]=="python -m venv .venv"
assert setup_steps[1]=="python -m pip install -r requirements.txt"
assert setup_steps[2]=="python -m unittest"
print("Checks passed")
