import sqlite3
def stored_names(names):
    with sqlite3.connect(":memory:") as db:
        db.execute("CREATE TABLE students(name TEXT)")
        db.executemany("INSERT INTO students VALUES (?)", [(name,) for name in names])
        return [row[0] for row in db.execute("SELECT name FROM students ORDER BY name")]

assert stored_names(["Sam","Asha"])==["Asha","Sam"]
assert stored_names(["O'Brien"])==["O'Brien"]
assert stored_names([])==[]
print("Checks passed")
