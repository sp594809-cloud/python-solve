import csv, io
def csv_names(text):
    return [row["name"] for row in csv.DictReader(io.StringIO(text))]
