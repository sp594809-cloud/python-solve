import json
def json_copy(record):
    return json.loads(json.dumps(record, ensure_ascii=False))
