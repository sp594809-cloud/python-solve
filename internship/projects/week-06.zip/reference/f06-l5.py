workflow = ["status", "diff", "add", "commit"]
