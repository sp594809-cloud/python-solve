import csv, io
def csv_names(text):
    return [row["name"] for row in csv.DictReader(io.StringIO(text))]

assert csv_names('name,score\nAsha,8\n')==['Asha']
assert csv_names('name,score\n"Patel, Krish",9\n')==['Patel, Krish']
assert csv_names('name,score\n')==[]
print("Checks passed")
