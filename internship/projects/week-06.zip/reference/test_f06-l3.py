import sqlite3
def stored_count(names):
    with sqlite3.connect(":memory:") as db:
        db.execute("CREATE TABLE students(name TEXT)")
        for name in names:
            db.execute("INSERT INTO students VALUES (?)",(name,))
        return db.execute("SELECT COUNT(*) FROM students").fetchone()[0]

assert stored_count(["Asha","Sam"])==2
assert stored_count(["O'Neil"])==1
assert stored_count([])==0
print("Checks passed")
