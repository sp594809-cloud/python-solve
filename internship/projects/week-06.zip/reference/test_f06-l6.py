def valid_record(record):
    name=record.get("name")
    score=record.get("score")
    return isinstance(name,str) and bool(name.strip()) and type(score) is int and 0<=score<=100

assert valid_record({"name":"Asha","score":80}) is True
assert valid_record({"name":" ","score":80}) is False
assert valid_record({"name":"A","score":True}) is False and valid_record({"name":"A","score":101}) is False
print("Checks passed")
