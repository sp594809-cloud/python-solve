import csv, io
def parse_scores(text):
    return [{"name": row["name"], "score": int(row["score"])} for row in csv.DictReader(io.StringIO(text))]
