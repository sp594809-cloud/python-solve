setup_steps = ["python -m venv .venv", "python -m pip install -r requirements.txt", "python -m unittest"]
