import csv, io
def parse_scores(text):
    return [{"name": row["name"], "score": int(row["score"])} for row in csv.DictReader(io.StringIO(text))]

assert parse_scores("name,score\nAsha,8\nSam,9\n")==[{"name":"Asha","score":8},{"name":"Sam","score":9}]
assert parse_scores('name,score\n"Patel, Krish",10\n')[0]["name"]=="Patel, Krish"
assert parse_scores("name,score\n")==[]
print("Checks passed")
