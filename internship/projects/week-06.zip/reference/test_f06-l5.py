workflow = ["status", "diff", "add", "commit"]

assert workflow==["status","diff","add","commit"]
print("Checks passed")
