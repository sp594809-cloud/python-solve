def valid_record(record):
    name=record.get("name")
    score=record.get("score")
    return isinstance(name,str) and bool(name.strip()) and type(score) is int and 0<=score<=100
