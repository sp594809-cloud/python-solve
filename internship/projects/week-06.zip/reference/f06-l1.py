import json
def read_name(text):
    return json.loads(text)["name"]
