import json
def json_copy(record):
    return json.loads(json.dumps(record, ensure_ascii=False))

assert json_copy({"scores":[1,2],"active":True})=={"scores":[1,2],"active":True}
assert json_copy({"name":"કૃશ"})["name"]=="કૃશ"
assert json_copy({})=={}
print("Checks passed")
