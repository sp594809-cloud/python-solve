import json
def read_name(text):
    return json.loads(text)["name"]

assert read_name('{"name":"Asha"}')=="Asha"
assert read_name('{"name":"કૃશ"}')=="કૃશ"
assert read_name('{"age":18,"name":"Sam"}')=="Sam"
print("Checks passed")
