# Week 6: Student records

Use CSV, JSON and SQL with explicit schemas.

## Your assignment
- Import sample CSV records.
- Store records in SQLite using parameters.
- Export JSON and test a name containing a quote.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## CSV with column names
Parse CSV text into name/score dictionaries with integer scores.

CSV is structured text, not a list of comma splits. DictReader uses the header as field names and correctly handles quoted values containing commas. Convert the score after parsing.

Try exercises/w06-l1.py before reading reference/w06-l1.py.

## JSON and data boundaries
Round-trip a dictionary through JSON and return the decoded value.

JSON is a language-independent data format. Serialization turns values into text; parsing turns that text into values. JSON object keys must be strings. Do not use eval to parse untrusted data.

Try exercises/w06-l2.py before reading reference/w06-l2.py.

## SQL parameters
Store names in an in-memory SQLite table and return them sorted.

SQL uses a different syntax from Python. Values belong in placeholders, not string concatenation. Parameter binding correctly handles apostrophes and prevents values from becoming SQL commands.

Try exercises/w06-l3.py before reading reference/w06-l3.py.
