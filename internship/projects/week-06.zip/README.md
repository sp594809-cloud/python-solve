# Week 6: Student records

Use CSV, JSON and SQL with explicit schemas.

## Your assignment
- Import sample CSV records.
- Store records in SQLite using parameters.
- Export JSON and test a name containing a quote.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## JSON is text; a dictionary is a Python value
Define read_name(text) by parsing JSON and returning its name field.

JSON is a text format used to exchange structured data. json.loads parses JSON text into Python values. json.dumps performs the reverse conversion.

A JSON string and a Python dictionary are not interchangeable. Inspect the boundary where data changes form. JSON requires double-quoted keys and has its own true, false and null spellings.

Try exercises/f06-l1.py before reading reference/f06-l1.py.

## CSV has quoting rules
Define csv_names(text) returning name values from a CSV with a header.

CSV stores rows with fields separated by delimiters. A field can itself contain a comma when it is properly quoted. A simple split(",") does not understand that rule.

csv.DictReader uses the header row as field names. StringIO lets us practise reading text as a file without needing an upload.

Try exercises/f06-l2.py before reading reference/f06-l2.py.

## SQL tables and parameterized values
Define stored_count(names): insert every name into SQLite and return the row count.

A relational database stores rows in tables with named columns. SQL describes operations such as CREATE TABLE, INSERT and SELECT.

Use ? placeholders for values. Parameters keep a name such as O’Neil separate from SQL syntax. Table and column names are fixed in this exercise; value parameters do not replace SQL identifiers.

Try exercises/f06-l3.py before reading reference/f06-l3.py.

## An environment keeps project dependencies separate
Complete setup_steps as the three commands: create .venv, install requirements, then run tests.

A virtual environment gives one project its own installed packages. pip installs packages for a Python interpreter. Using python -m pip helps target the interpreter you selected.

These are terminal commands, not Python statements. In this exercise you store them as text to learn their order. On a laptop, activate the environment using the OS-specific command in the project README before installing.

Try exercises/f06-l4.py before reading reference/f06-l4.py.

## Git records a reviewable change
Store workflow as status, diff, add, commit in that order.

Git tracks snapshots of files in commits. The working tree contains your edits. Staging selects which edits will enter the next commit. A remote repository is a separate location such as GitHub.

Inspect status and diff before staging so you know what you are committing. Keep changes small enough that a reviewer can explain them. Never include private keys or real student data in a practice repository.

Try exercises/f06-l5.py before reading reference/f06-l5.py.

## Validate structured records at the boundary
Define valid_record(record): True only for a nonblank string name and integer score from 0 to 100, excluding bool.

External data can be missing fields or contain the wrong type. Validate it before calculation or storage. State the input contract in ordinary language, then translate each requirement into a check.

Python bool is a subclass of int. An exact type check excludes True from an integer-only score contract. This is a deliberate rule for this exercise.

Try exercises/f06-l6.py before reading reference/f06-l6.py.

## CSV with column names
Parse CSV text into name/score dictionaries with integer scores.

CSV is structured text, not a list of comma splits. DictReader uses the header as field names and correctly handles quoted values containing commas. Convert the score after parsing.

Try exercises/w06-l1.py before reading reference/w06-l1.py.

## JSON and data boundaries
Round-trip a dictionary through JSON and return the decoded value.

JSON is a language-independent data format. Serialization turns values into text; parsing turns that text into values. JSON object keys must be strings. Do not use eval to parse untrusted data.

Try exercises/w06-l2.py before reading reference/w06-l2.py.

## SQL parameters
Store names in an in-memory SQLite table and return them sorted.

SQL uses a different syntax from Python. Values belong in placeholders, not string concatenation. Parameter binding correctly handles apostrophes and prevents values from becoming SQL commands.

Try exercises/w06-l3.py before reading reference/w06-l3.py.

### JSON is text; a dictionary is a Python value — walkthrough
- The outer Python quotes hold JSON text.
- loads produces a dictionary for this object.

Expected output: Sam

Common mistake: Calling text["name"] on the original JSON string fails. Parse it first.

Watch: [Libraries](https://www.youtube.com/watch?v=MztLZWibctI) — Harvard CS50 · David Malan (English). Follow imports, pip, JSON and the main-module pattern. Practise with the supplied local fixtures before live APIs.

### CSV has quoting rules — walkthrough
- DictReader reads the header.
- Each following row becomes a mapping from header name to text.

Expected output: ['Sam']

Common mistake: CSV numbers arrive as strings. Convert them explicitly if you need numeric calculations.

Watch: [File I/O](https://www.youtube.com/watch?v=KD-Yoel6EVQ) — Harvard CS50 · David Malan (English). Follow text files and CSV examples; try one Unicode value yourself.

### SQL tables and parameterized values — walkthrough
- The database lives in memory for this demonstration.
- The tuple (8,) supplies one parameter.
- fetchone returns one result row.

Expected output: 1

Common mistake: Do not insert user text into SQL using f-strings. Supply it as a parameter tuple.

Watch: [Python SQLite: Database, Tables and Queries](https://www.youtube.com/watch?v=pd-0G0MigUA) — Corey Schafer (English). Follow table creation, inserts and parameterized values using sample data.

### An environment keeps project dependencies separate — walkthrough
- Start with isolation.
- Install the dependencies documented by the project.
- Run tests before changing code.

Expected output: create environment

Common mistake: Typing pip install inside an ordinary Python script is a syntax error. It is a terminal command.

Watch: [Virtual Environments: venv on Mac and Linux](https://www.youtube.com/watch?v=Kg1Yvry_Ydk) — Corey Schafer (English). Learn environment creation and dependency isolation. Windows activation commands are provided in the project README.

### Git records a reviewable change — walkthrough
- Inspection comes before publishing a snapshot.
- A local commit can exist without an internet connection.

Expected output: commit

Common mistake: git add is not an upload. git commit is a local snapshot. git push sends commits to a configured remote.

Watch: [Git](https://www.youtube.com/watch?v=NcoBAfJ6l2Q) — Harvard CS50 · Brian Yu (English). Practise status, commits and branches in a disposable learning repository.

### Validate structured records at the boundary — walkthrough
- Check types before calling type-specific methods.
- A clear boundary prevents failures deeper in the program.

Expected output: True

Common mistake: A truthiness check would reject the valid score zero. Separate range validation from existence.

Watch: [Dictionaries: Working with Key-Value Pairs](https://www.youtube.com/watch?v=daefaLgNkw0) — Corey Schafer (English). Practise reading, updating and safely looking up dictionary values.

Watch: [File I/O](https://www.youtube.com/watch?v=KD-Yoel6EVQ) — Harvard CS50 · David Malan (English). Follow text files and CSV examples; try one Unicode value yourself.

Watch: [File I/O](https://www.youtube.com/watch?v=KD-Yoel6EVQ) — Harvard CS50 · David Malan (English). Follow text files and CSV examples; try one Unicode value yourself.

Watch: [Python SQLite: Database, Tables and Queries](https://www.youtube.com/watch?v=pd-0G0MigUA) — Corey Schafer (English). Follow table creation, inserts and parameterized values using sample data.
