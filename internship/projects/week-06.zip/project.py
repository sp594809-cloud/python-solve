import csv,io,json,sqlite3
def import_records(csv_text):
    records=list(csv.DictReader(io.StringIO(csv_text)))
    with sqlite3.connect(":memory:") as db:
        db.execute("CREATE TABLE students(name TEXT, score INTEGER)")
        db.executemany("INSERT INTO students VALUES (?,?)",[(r["name"],int(r["score"])) for r in records])
        return [{"name":name,"score":score} for name,score in db.execute("SELECT name,score FROM students ORDER BY name")]
if __name__=="__main__":print(json.dumps(import_records("name,score\nAsha,8\nO'Neil,9\n"),ensure_ascii=False,indent=2))
