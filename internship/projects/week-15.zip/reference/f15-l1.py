def overlap(query, text):
    return len(set(query.lower().split()) & set(text.lower().split()))
