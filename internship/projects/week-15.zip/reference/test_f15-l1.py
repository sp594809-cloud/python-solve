def overlap(query, text):
    return len(set(query.lower().split()) & set(text.lower().split()))

assert overlap("python lists","lists python order")==2
assert overlap("weather","python")==0
assert overlap("AI AI","ai")==1
print("Checks passed")
