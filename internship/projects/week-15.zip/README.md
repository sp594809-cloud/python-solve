# Week 15: Notes search assistant

Return grounded evidence and distinguish retrieval from generation.

## Your assignment
- Index supplied notes and return relevant source IDs.
- Show no-match behaviour.
- Try paraphrases and document lexical-search limitations.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Retrieval finds evidence before an answer
Define overlap(query,text), counting distinct shared lowercase whitespace-separated words.

A retrieval system searches stored information for evidence related to a query. A lexical system matches words; it may miss a paraphrase that uses different words.

Generation is a separate step that writes new text. Start by making retrieval measurable: save test queries, expected source IDs and no-match examples. Add an LLM only when you can evaluate whether it improves the task.

Try exercises/f15-l1.py before reading reference/f15-l1.py.

## Retrieve notes with evidence
Return matching note IDs ranked by shared lowercase words, breaking ties by ID.

Retrieval finds existing evidence. This simple lexical search does not understand paraphrases like an embedding model. Return IDs so a reader can inspect the source, and return no match when overlap is zero.

Try exercises/w15-l1.py before reading reference/w15-l1.py.

## Ground an answer in its source
Return a selected note’s exact text and ID, or an explicit no-match response.

A retrieval assistant should not invent an answer when evidence is absent. This function returns stored text, not generated prose. A future LLM layer must preserve attribution and be evaluated separately.

Try exercises/w15-l2.py before reading reference/w15-l2.py.

## Verify AI-suggested changes
Reject a patch review unless tests, explanation and secret checks are all satisfied.

AI can help draft code, but you own the result. Run tests, explain the change without the assistant and inspect for credentials. A checklist is a review reminder, not a security scanner or proof that code is correct.

Try exercises/w15-l3.py before reading reference/w15-l3.py.

### Retrieval finds evidence before an answer — walkthrough
- The ampersand finds the shared set members.
- Only lists appears in both sets.

Expected output: 1

Common mistake: A matching word does not prove a source answers the question. Inspect the retrieved evidence and test misleading matches.

Watch: [Language: Words, Representation and AI](https://www.youtube.com/watch?v=QAZc9xsQNjQ) — Harvard CS50 · Brian Yu (English). Advanced extension: focus on bag-of-words and word representation after the lexical search lesson. The neural-network material is optional.

Watch: [Language: Words, Representation and AI](https://www.youtube.com/watch?v=QAZc9xsQNjQ) — Harvard CS50 · Brian Yu (English). Advanced extension: focus on bag-of-words and word representation after the lexical search lesson. The neural-network material is optional.

Watch: [Language: Words, Representation and AI](https://www.youtube.com/watch?v=QAZc9xsQNjQ) — Harvard CS50 · Brian Yu (English). Advanced extension: focus on bag-of-words and word representation after the lexical search lesson. The neural-network material is optional.

Watch: [Language: Words, Representation and AI](https://www.youtube.com/watch?v=QAZc9xsQNjQ) — Harvard CS50 · Brian Yu (English). Advanced extension: focus on bag-of-words and word representation after the lexical search lesson. The neural-network material is optional.
