def overlap(query, text):
    pass
