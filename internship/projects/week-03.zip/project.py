scores = {"Python": 8, "Maths": 6, "English": 7}
total = 0
for subject, score in scores.items():
    total += score
    if score < 7:
        print("Revise:", subject)
print("Total:", total)
print("Distinct subjects:", len(set(scores)))
