# Create numbers for 1 through 5.
