count = 3
seen = []
# Write the countdown loop.
