numbers = [2, 4, 6]
total = 0
# Add each number.
