# Create student, then read score.
