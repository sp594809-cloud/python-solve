subjects = ["Python", "Maths"]
# Append and read the first item.
