skills = ["python", "web", "python"]
# Create unique.
