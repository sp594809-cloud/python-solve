stock = {"pen": 5}
# Create erasers and has_pen.
