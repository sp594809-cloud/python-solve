location = ("Ahmedabad", 380001)
# Unpack into city and postcode.
