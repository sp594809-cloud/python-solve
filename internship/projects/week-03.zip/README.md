# Week 3: Subject tracker

Use lists, loops, tuples, sets and dictionaries before writing functions.

## Your assignment
- Store subjects and scores in a dictionary.
- Loop to calculate a total and identify a low score.
- Test an empty collection and duplicate names.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## A list stores an ordered collection
Make subjects=["Python","Maths"], append "English", and store the first subject in first.

A list groups several values in order. Square brackets create a list. Like strings, list indexes start at zero.

Lists are mutable. append changes the existing list by adding one value at the end. Its return value is None, so do not assign the result of append back to the list.

Try exercises/f03-l1.py before reading reference/f03-l1.py.

## Loop over a list one item at a time
Sum the numbers [2,4,6] into total using a loop.

A for loop gives a name to the next item and runs its body for each item. The name changes on each iteration.

An accumulator stores a result that grows across iterations. Initialize it before the loop. If you reset total inside the loop, you lose earlier work.

Try exercises/f03-l2.py before reading reference/f03-l2.py.

## range counts without a written list
Create numbers containing 1 through 5 using range and list.

range(start, stop) represents integers from start up to, but not including, stop. list converts that range into a visible list.

A stop value is a boundary, not the final item. Write the desired first and last numbers before choosing the arguments.

Try exercises/f03-l3.py before reading reference/f03-l3.py.

## A while loop must make progress
Start count at 3 and append 3,2,1 to seen while reducing count to zero.

while repeats as long as its condition remains true. Unlike for, it does not automatically move to a next item. Your body must change the condition eventually.

If the value never changes, the loop can run forever. Use Stop in the quick runner or restart the notebook kernel when a loop gets stuck.

Try exercises/f03-l4.py before reading reference/f03-l4.py.

## Tuples and unpacking
Unpack location=("Ahmedabad",380001) into city and postcode.

A tuple groups ordered values that you do not intend to change in place. Parentheses usually make it visible. Unpacking assigns each position to a separate name.

Use a tuple for a small fixed record, such as a coordinate. Use a dictionary when field names will make the data clearer.

Try exercises/f03-l5.py before reading reference/f03-l5.py.

## Sets remove duplicates
Create unique from ["python","web","python"] as a set.

A set stores distinct values. It is useful for membership checks and removing duplicates. A set does not promise the display order you want.

Sort a set when a stable presentation order matters. Do not use a set when duplicate items represent meaningful counts.

Try exercises/f03-l6.py before reading reference/f03-l6.py.

## Dictionaries use names instead of positions
Create student with name Asha and score 8; store student["score"] in score.

A dictionary maps keys to values. Keys are useful field names such as name or score. Access a value with its key in square brackets.

This is easier to read than remembering that position 0 is a name and position 1 is a score. Dictionary keys are unique: assigning an existing key updates that value.

Try exercises/f03-l7.py before reading reference/f03-l7.py.

## Safe lookups and membership
Read missing stock for eraser using a default of 0; check whether pen is present.

A square-bracket lookup raises KeyError for a missing dictionary key. get(key, default) provides a chosen fallback. Use in to ask whether a key exists.

Choose a fallback that makes sense for the domain. Zero stock is different from missing medical data, so defaults are decisions, not magic fixes.

Try exercises/f03-l8.py before reading reference/f03-l8.py.

## Lists and safe iteration
Return the names longer than three characters, without changing the original list.

Lists preserve order. Create a new result instead of removing items while iterating. Removing from the same list can skip the next item as indexes move.

Try exercises/w03-l1.py before reading reference/w03-l1.py.

## Dictionaries and counting
Count each category in an expense list.

A dictionary maps a key to a value. get(key, 0) supplies an initial count for a new key. This avoids a separate branch for the first occurrence.

Try exercises/w03-l2.py before reading reference/w03-l2.py.

## Sets and uniqueness
Return unique lowercase names in sorted order.

A set removes duplicates but does not provide a useful display order. Normalize case before deduplication, then sort for predictable output. This is a small data-cleaning pipeline.

Try exercises/w03-l3.py before reading reference/w03-l3.py.

### A list stores an ordered collection — walkthrough
- The original list has two items.
- append adds a third item.
- len counts items, not characters.

Expected output: read
3

Common mistake: subjects = subjects.append(...) replaces your list with None. Call append as a statement.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.

### Loop over a list one item at a time — walkthrough
- Before the loop total is zero.
- The first iteration adds three.
- The second adds five to the existing three.

Expected output: 8

Common mistake: Return and break end work early; this script needs neither. Let all iterations finish.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.

### range counts without a written list — walkthrough
- Start at two.
- Stop before five.

Expected output: [2, 3, 4]

Common mistake: range(1,5) omits five. This is a common boundary error.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.

### A while loop must make progress — walkthrough
- The condition is checked before every iteration.
- Subtracting one makes progress toward zero.

Expected output: 2
1

Common mistake: A loop body that only prints count never changes count. Add an update.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.

### Tuples and unpacking — walkthrough
- The first value goes to x.
- The second goes to y.

Expected output: 11

Common mistake: Unpacking three values into two names raises ValueError. Match the number of positions.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.

### Sets remove duplicates — walkthrough
- The repeated code value appears once.
- len counts distinct values.

Expected output: 2

Common mistake: {} creates an empty dictionary. Use set() for an empty set.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.

### Dictionaries use names instead of positions — walkthrough
- Each key is followed by a colon and its value.
- The lookup uses the exact key pages.

Expected output: 12

Common mistake: student[score] looks for the value stored in a variable called score. student["score"] uses the literal key.

Watch: [Dictionaries: Working with Key-Value Pairs](https://www.youtube.com/watch?v=daefaLgNkw0) — Corey Schafer (English). Practise reading, updating and safely looking up dictionary values.

### Safe lookups and membership — walkthrough
- The missing key receives the fallback zero.
- Membership checks dictionary keys.

Expected output: 0
True

Common mistake: Testing a value with in on a dictionary checks keys. Use .values() if you truly need to inspect values.

Watch: [Dictionaries: Working with Key-Value Pairs](https://www.youtube.com/watch?v=daefaLgNkw0) — Corey Schafer (English). Practise reading, updating and safely looking up dictionary values.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.

Watch: [Dictionaries: Working with Key-Value Pairs](https://www.youtube.com/watch?v=daefaLgNkw0) — Corey Schafer (English). Practise reading, updating and safely looking up dictionary values.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.
