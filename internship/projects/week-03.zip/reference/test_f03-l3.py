numbers = list(range(1, 6))

assert numbers==[1,2,3,4,5]
print("Checks passed")
