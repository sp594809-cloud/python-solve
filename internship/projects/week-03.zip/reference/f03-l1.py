subjects = ["Python", "Maths"]
subjects.append("English")
first = subjects[0]
