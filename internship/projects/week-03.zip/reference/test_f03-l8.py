stock = {"pen": 5}
erasers = stock.get("eraser", 0)
has_pen = "pen" in stock

assert erasers==0
assert has_pen is True
print("Checks passed")
