subjects = ["Python", "Maths"]
subjects.append("English")
first = subjects[0]

assert subjects==["Python","Maths","English"]
assert first=="Python"
print("Checks passed")
