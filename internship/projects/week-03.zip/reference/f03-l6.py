skills = ["python", "web", "python"]
unique = set(skills)
