numbers = [2, 4, 6]
total = 0
for number in numbers:
    total += number
