location = ("Ahmedabad", 380001)
city, postcode = location

assert city=="Ahmedabad"
assert postcode==380001
print("Checks passed")
