student = {"name":"Asha", "score":8}
score = student["score"]

assert student=={"name":"Asha","score":8}
assert score==8
print("Checks passed")
