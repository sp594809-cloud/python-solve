count = 3
seen = []
while count > 0:
    seen.append(count)
    count -= 1

assert seen==[3,2,1]
assert count==0
print("Checks passed")
