location = ("Ahmedabad", 380001)
city, postcode = location
