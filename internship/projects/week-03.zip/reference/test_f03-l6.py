skills = ["python", "web", "python"]
unique = set(skills)

assert unique=={"python","web"}
assert type(unique) is set
print("Checks passed")
