count = 3
seen = []
while count > 0:
    seen.append(count)
    count -= 1
