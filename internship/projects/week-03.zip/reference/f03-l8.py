stock = {"pen": 5}
erasers = stock.get("eraser", 0)
has_pen = "pen" in stock
