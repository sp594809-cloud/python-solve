student = {"name":"Asha", "score":8}
score = student["score"]
