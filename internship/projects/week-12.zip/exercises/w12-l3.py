def health(database_ok, model_ok):
    # TODO: implement the task. Keep the function name and parameters.
    pass
