def app_mode(environment):
    # TODO: implement the task. Keep the function name and parameters.
    pass
