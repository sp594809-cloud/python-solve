from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator
app=FastAPI(title="Student task demo")
tasks=[]
class TaskInput(BaseModel):
    title:str=Field(min_length=1,max_length=200)
    @field_validator("title")
    @classmethod
    def clean(cls,value):
        if not value.strip():raise ValueError("title required")
        return value.strip()
@app.get("/")
def home():return FileResponse(Path(__file__).with_name("index.html"))
@app.get("/health")
def health():return {"ready":True,"mode":"demo"}
@app.get("/tasks")
def list_tasks():return tasks
@app.post("/tasks",status_code=201)
def add_task(data:TaskInput):
    task={"id":len(tasks)+1,"title":data.title,"done":False};tasks.append(task);return task
@app.patch("/tasks/{task_id}")
def complete(task_id:int):
    for task in tasks:
        if task["id"]==task_id:task["done"]=True;return task
    raise HTTPException(404,"Task not found")
