import unittest
from fastapi.testclient import TestClient
from app import app
class Routes(unittest.TestCase):
    def test_contract(self):
        c=TestClient(app)
        self.assertEqual(c.get('/health').status_code,200)
        self.assertEqual(c.get('/').status_code,200)
        self.assertEqual(c.post('/tasks',json={"title":" "}).status_code,422)
        r=c.post('/tasks',json={"title":" Read "});self.assertEqual(r.status_code,201)
        self.assertEqual(r.json()['title'],'Read')
        self.assertTrue(c.patch('/tasks/'+str(r.json()['id'])).json()['done'])
        self.assertEqual(c.patch('/tasks/9999').status_code,404)
if __name__=='__main__':unittest.main()
