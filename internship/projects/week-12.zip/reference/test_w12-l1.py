def app_mode(environment):
    value = environment.get("APP_MODE", "demo")
    return value if value in {"demo", "production"} else "demo"

assert app_mode({})=="demo"
assert app_mode({"APP_MODE":"production"})=="production"
assert app_mode({"APP_MODE":"debug"})=="demo"
print("Checks passed")
