def public_error(error, request_id):
    return {"error":"Something went wrong", "request_id":request_id}
