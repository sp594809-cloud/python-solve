def health(database_ok, model_ok):
    return {"ready":bool(database_ok and model_ok)}
