def health(database_ok, model_ok):
    return {"ready":bool(database_ok and model_ok)}

assert health(True,True)=={"ready":True}
assert health(False,True)=={"ready":False}
assert health(True,False)=={"ready":False}
print("Checks passed")
