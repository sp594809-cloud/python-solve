def app_mode(environment):
    value = environment.get("APP_MODE", "demo")
    return value if value in {"demo", "production"} else "demo"
