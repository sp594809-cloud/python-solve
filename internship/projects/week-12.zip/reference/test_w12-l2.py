def public_error(error, request_id):
    return {"error":"Something went wrong", "request_id":request_id}

assert public_error(Exception("secret"),"r1")=={"error":"Something went wrong","request_id":"r1"}
assert "password" not in str(public_error(Exception("password=123"),"r2"))
assert set(public_error(ValueError(),"r3"))=={"error","request_id"}
print("Checks passed")
