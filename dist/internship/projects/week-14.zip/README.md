# Week 14: Ticket classifier

Train a scikit-learn model and measure held-out behaviour.

## Your assignment
- Train a text classifier on labelled examples.
- Evaluate on unseen messages and compare a baseline.
- Inspect wrong predictions and state dataset limitations.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```
Install requirements first: python -m pip install -r requirements.txt. Synthetic data is deliberately small; replace it with documented, permissioned data before making performance claims.

## Understand a text pipeline before fitting it
Define tokens(text) returning sorted unique lowercase whitespace-separated words.

A text classifier cannot directly multiply words as numbers. A vectorizer converts text into numeric features. TF-IDF gives a token a weight based on its frequency in a document and across the training collection.

The small tokenizer below is a preparation exercise, not a complete TF-IDF vectorizer. The next lesson uses scikit-learn’s tested implementation inside a pipeline with logistic regression.

Try exercises/f14-l1.py before reading reference/f14-l1.py.

## Fit a real text classifier
Train and return a fitted TF-IDF + LogisticRegression pipeline.

A pipeline fits text preprocessing and a classifier together on training examples. This is a small machine-learning model, not an LLM. Keep test messages out of fit. The download includes synthetic training and held-out fixtures and a baseline.

Try exercises/w14-l1.py before reading reference/w14-l1.py.

## Evaluate held-out predictions
Return accuracy, rejecting empty or mismatched lists.

Accuracy is correct predictions divided by the number of examples. Always show the sample count and compare a majority-class baseline. A tiny fixture is for learning, not a reliable claim about future users.

Try exercises/w14-l2.py before reading reference/w14-l2.py.

## Inspect errors instead of hiding them
Return indexes of wrong predictions. Reject lists of unequal length.

An overall score hides patterns. Read wrong examples, check the label quality and document what the model confuses. Do not repeatedly tune on your final test set; use a validation set for development.

Try exercises/w14-l3.py before reading reference/w14-l3.py.

### Understand a text pipeline before fitting it — walkthrough
- Normalize case before counting distinct words.
- A real vectorizer has documented tokenization rules beyond this simple split.

Expected output: ['python', 'web']

Common mistake: Fitting the vectorizer on all data before a split leaks test information. Fit the entire pipeline on training data.

Watch: [A Gentle Introduction to Machine Learning](https://www.youtube.com/watch?v=Gv9_4yMHFhI) — StatQuest · Josh Starmer (English). Learn the training/test distinction before fitting the course model.

Watch: [A Gentle Introduction to Machine Learning](https://www.youtube.com/watch?v=Gv9_4yMHFhI) — StatQuest · Josh Starmer (English). Learn the training/test distinction before fitting the course model.

Watch: [Machine Learning Fundamentals: The Confusion Matrix](https://www.youtube.com/watch?v=Kdsp6soqA7o) — StatQuest · Josh Starmer (English). Read the types of correct and incorrect predictions rather than only accuracy.

Watch: [Machine Learning Fundamentals: The Confusion Matrix](https://www.youtube.com/watch?v=Kdsp6soqA7o) — StatQuest · Josh Starmer (English). Read the types of correct and incorrect predictions rather than only accuracy.
