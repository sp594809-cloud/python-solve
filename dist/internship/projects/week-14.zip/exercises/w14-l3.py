def mistakes(actual, predicted):
    # TODO: implement the task. Keep the function name and parameters.
    pass
