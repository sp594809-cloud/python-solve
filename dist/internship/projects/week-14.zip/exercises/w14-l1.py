def train_classifier(texts, labels):
    # TODO: implement the task. Keep the function name and parameters.
    pass
