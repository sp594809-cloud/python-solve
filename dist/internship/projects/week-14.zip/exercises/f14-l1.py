def tokens(text):
    pass
