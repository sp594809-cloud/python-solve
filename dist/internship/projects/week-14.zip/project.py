from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score,classification_report
texts=["invoice payment","billing refund","refund invoice","payment charge","login password","account login","reset password","login access"]
labels=["billing"]*4+["technical"]*4
heldout=["invoice charge","refund payment","password login","account password"]
truth=["billing","billing","technical","technical"]
model=make_pipeline(TfidfVectorizer(),LogisticRegression(random_state=42));model.fit(texts,labels)
predicted=model.predict(heldout)
baseline=DummyClassifier(strategy="most_frequent").fit([[0]]*len(labels),labels)
print("Synthetic held-out sample count:",len(truth));print("Model accuracy:",accuracy_score(truth,predicted));print("Baseline:",accuracy_score(truth,baseline.predict([[0]]*len(truth))))
print(classification_report(truth,predicted,zero_division=0))
for text,a,p in zip(heldout,truth,predicted):
    if a!=p:print("Mistake:",text,a,p)
print("Tiny synthetic fixture: not real-world performance evidence.")
