def tokens(text):
    return sorted(set(text.lower().split()))

assert tokens("AI ai Python")==["ai","python"]
assert tokens(" ")==[]
assert tokens('web\npython')==["python","web"]
print("Checks passed")
