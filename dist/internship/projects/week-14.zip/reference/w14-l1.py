from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
def train_classifier(texts, labels):
    model = make_pipeline(TfidfVectorizer(), LogisticRegression(random_state=42))
    return model.fit(texts, labels)
