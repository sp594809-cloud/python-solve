from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
def train_classifier(texts, labels):
    model = make_pipeline(TfidfVectorizer(), LogisticRegression(random_state=42))
    return model.fit(texts, labels)

m=train_classifier(["invoice payment","billing refund","login password","account login"],["billing","billing","technical","technical"]);assert m.predict(["invoice"])[0]=="billing"
m=train_classifier(["invoice payment","billing refund","login password","account login"],["billing","billing","technical","technical"]);assert m.predict(["login"])[0]=="technical"
m=train_classifier(["invoice payment","billing refund","login password","account login"],["billing","billing","technical","technical"]);assert len(m.predict(["invoice","password"]))==2
print("Checks passed")
