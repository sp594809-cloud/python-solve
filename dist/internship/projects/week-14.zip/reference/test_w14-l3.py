def mistakes(actual, predicted):
    if len(actual) != len(predicted):
        raise ValueError("length mismatch")
    return [i for i,(a,p) in enumerate(zip(actual,predicted)) if a!=p]

assert mistakes(["a","b","a"],["b","b","b"])==[0,2]
assert mistakes([1],[1])==[]
try:
 mistakes([1],[])
except ValueError:
 pass
else:
 raise AssertionError("Expected ValueError")
print("Checks passed")
