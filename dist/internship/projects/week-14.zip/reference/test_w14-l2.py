def accuracy(actual, predicted):
    if not actual or len(actual) != len(predicted):
        raise ValueError("nonempty equal lengths required")
    return sum(a==p for a,p in zip(actual,predicted))/len(actual)

assert accuracy(["a","b","a"],["a","a","a"])==2/3
assert accuracy([1],[2])==0
for a,p in [([],[]),([1],[])]:
 try:
  accuracy(a,p)
 except ValueError:
  pass
 else:
  raise AssertionError("Expected ValueError")
print("Checks passed")
