def mistakes(actual, predicted):
    if len(actual) != len(predicted):
        raise ValueError("length mismatch")
    return [i for i,(a,p) in enumerate(zip(actual,predicted)) if a!=p]
