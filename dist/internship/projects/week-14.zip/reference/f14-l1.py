def tokens(text):
    return sorted(set(text.lower().split()))
