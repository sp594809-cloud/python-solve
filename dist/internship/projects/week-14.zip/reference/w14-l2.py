def accuracy(actual, predicted):
    if not actual or len(actual) != len(predicted):
        raise ValueError("nonempty equal lengths required")
    return sum(a==p for a,p in zip(actual,predicted))/len(actual)
