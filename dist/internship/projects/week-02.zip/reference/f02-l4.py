score = 40
passed = score >= 40
perfect = score == 100
