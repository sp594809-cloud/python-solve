has_id = True
fee_paid = False
can_enter = has_id and fee_paid
needs_help = not has_id or not fee_paid

assert can_enter is False
assert needs_help is True
print("Checks passed")
