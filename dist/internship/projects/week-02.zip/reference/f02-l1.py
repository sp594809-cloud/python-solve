word = "PYTHON"
first = word[0]
middle = word[1:4]
