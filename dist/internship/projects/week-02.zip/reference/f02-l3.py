name = "Asha"
minutes = 30
message = f"{name} studied {minutes} minutes."
