def positive_total(amounts):
    total = 0
    for amount in amounts:
        if amount > 0:
            total += amount
    return total

assert positive_total([3,-2,5,0])==8
assert positive_total([])==0
assert positive_total([-4,-1])==0
print("Checks passed")
