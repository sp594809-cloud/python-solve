temperature = 35
if temperature >= 30:
    advice = "Drink water"
else:
    advice = "Comfortable"

assert advice=="Drink water"
print("Checks passed")
