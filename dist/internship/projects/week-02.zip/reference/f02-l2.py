raw_name = "  Krish  "
clean_name = raw_name.strip().lower()
