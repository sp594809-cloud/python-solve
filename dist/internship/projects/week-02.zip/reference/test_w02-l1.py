def result(score):
    if not 0 <= score <= 100:
        return "invalid"
    return "pass" if score >= 40 else "retry"

assert result(40)=="pass"
assert result(39)=="retry"
assert result(-1)==result(101)=="invalid"
print("Checks passed")
