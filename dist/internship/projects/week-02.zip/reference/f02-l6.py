temperature = 35
if temperature >= 30:
    advice = "Drink water"
else:
    advice = "Comfortable"
