score = 40
passed = score >= 40
perfect = score == 100

assert passed is True
assert perfect is False
print("Checks passed")
