score = 60
message = "Try again"
if score >= 40:
    message = "Passed"

assert message=="Passed"
print("Checks passed")
