def digit_count(number):
    number = abs(number)
    if number == 0:
        return 1
    count = 0
    while number:
        count += 1
        number //= 10
    return count
