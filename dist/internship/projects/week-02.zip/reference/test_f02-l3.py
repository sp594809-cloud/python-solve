name = "Asha"
minutes = 30
message = f"{name} studied {minutes} minutes."

assert message=="Asha studied 30 minutes."
print("Checks passed")
