raw_name = "  Krish  "
clean_name = raw_name.strip().lower()

assert clean_name=="krish"
assert raw_name=="  Krish  "
print("Checks passed")
