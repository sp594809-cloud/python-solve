word = "PYTHON"
first = word[0]
middle = word[1:4]

assert first=="P"
assert middle=="YTH"
print("Checks passed")
