def positive_total(amounts):
    total = 0
    for amount in amounts:
        if amount > 0:
            total += amount
    return total
