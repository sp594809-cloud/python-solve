def result(score):
    if not 0 <= score <= 100:
        return "invalid"
    return "pass" if score >= 40 else "retry"
