def digit_count(number):
    number = abs(number)
    if number == 0:
        return 1
    count = 0
    while number:
        count += 1
        number //= 10
    return count

assert digit_count(0)==1
assert digit_count(-120)==3
assert digit_count(987654)==6
print("Checks passed")
