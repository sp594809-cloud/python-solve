name = "  Asha  ".strip()
score = 65
if score >= 80:
    advice = "Try a new challenge"
elif score >= 40:
    advice = "Practise one weak topic"
else:
    advice = "Review the worked example"
print(f"{name}: {advice}")
