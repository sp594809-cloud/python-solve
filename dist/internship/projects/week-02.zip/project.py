def summarize(expenses):
    total=0; counts={}
    for category,amount in expenses:
        if not isinstance(amount,(int,float)) or amount<0:
            raise ValueError("Use nonnegative numeric amounts")
        total+=amount;counts[category]=counts.get(category,0)+1
    return {"total":round(total,2),"categories":counts}
if __name__=="__main__":
    print(summarize([("food",50),("travel",20),("food",30)]))
