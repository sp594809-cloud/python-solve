# Week 2: Study-day decision tool

Clean text and choose branches with comparisons and boolean rules.

## Your assignment
- Clean a student name and build a readable message.
- Choose a study message from a score using if/elif/else.
- Test values just below and at each boundary.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Read and slice a string
For word="PYTHON", store first="P" and middle="YTH" using indexes and a slice.

A string is an ordered sequence of characters. Index zero refers to the first character. A slice start:stop includes start and excludes stop.

Draw indexes above the word before writing a slice. This makes off-by-one mistakes visible.

Try exercises/f02-l1.py before reading reference/f02-l1.py.

## Clean text without changing the original
Create clean_name="krish" from raw_name="  Krish  ". Keep raw_name unchanged.

A string method is an operation accessed with a dot. strip removes surrounding whitespace. lower converts letters to lowercase.

Strings are immutable: these methods return new strings. You must store the result if you want to use the cleaned value later.

Try exercises/f02-l2.py before reading reference/f02-l2.py.

## Write a readable message with f-strings
Build message="Asha studied 30 minutes." from name and minutes.

An f-string begins with f before the opening quote. Expressions inside braces are evaluated and inserted into the text.

This keeps the human sentence visible while values can change. Keep spaces and punctuation outside braces intentional.

Try exercises/f02-l3.py before reading reference/f02-l3.py.

## Compare values and understand booleans
With score=40, create passed using >=40 and perfect using ==100.

A comparison produces True or False. >= includes the boundary; > excludes it. Use == to compare two values and = to assign a value.

Read a comparison as a yes/no question. This boolean result will decide which branch runs in the next lesson.

Try exercises/f02-l4.py before reading reference/f02-l4.py.

## Your first if block and indentation
Start message="Try again". If score=60 is at least 40, change message to "Passed".

An if statement runs an indented block only when its condition is true. The colon introduces the block. Use four spaces consistently at the start of each line inside it.

A notebook helps insert indentation but cannot know which lines you intended to group. A line at the left edge is outside the block.

Try exercises/f02-l5.py before reading reference/f02-l5.py.

## Choose between two branches
For temperature=35, set advice to "Drink water" when temperature>=30, otherwise "Comfortable".

else gives an alternative when an if condition is false. The if and else keywords align. Each branch has its own indented body.

Exactly one branch runs in an if/else pair. Trace the condition first, then ignore the branch that was not selected.

Try exercises/f02-l6.py before reading reference/f02-l6.py.

## Multiple branches and their order
For score=75, assign grade A for >=80, B for >=60, otherwise C.

elif checks another condition only if earlier conditions were false. Put the more specific or higher boundary first when ranges overlap.

For score 90, both >=60 and >=80 are true. If >=60 comes first, Python chooses that branch and never checks >=80.

Try exercises/f02-l7.py before reading reference/f02-l7.py.

## Combine conditions with and, or and not
With has_id=True and fee_paid=False, set can_enter only when both are True. Set needs_help when either is False.

and requires both conditions to be true. or needs at least one. not reverses a boolean. Parentheses make a longer decision easier to read.

Describe the rule in normal words before writing it. Then try all four combinations of two boolean inputs.

Try exercises/f02-l8.py before reading reference/f02-l8.py.

## Choose the right branch
Return pass for a score of 40 or more, otherwise retry. Reject scores outside 0–100.

Check invalid input before normal branches. The boundary value 40 belongs to pass; using > would incorrectly reject it. Tests just below and at a boundary are especially useful.

Try exercises/w02-l1.py before reading reference/w02-l1.py.

## Trace a for loop
Sum only positive amounts from a list.

An accumulator starts at zero and changes on each matching item. Trace total after every iteration before running the loop. Empty input naturally keeps the initial value.

Try exercises/w02-l2.py before reading reference/w02-l2.py.

## A terminating while loop
Count the decimal digits of an integer, including zero.

A while loop must make progress toward its stopping condition. Integer division by 10 removes the final decimal digit. abs handles a negative sign; zero itself has one digit.

Try exercises/w02-l3.py before reading reference/w02-l3.py.

### Read and slice a string — walkthrough
- Index zero selects C.
- The slice reads positions 1, 2 and 3, stopping before 4.

Expected output: C
ODI

Common mistake: word[6] fails for a six-character word: the last index is 5.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Clean text without changing the original — walkthrough
- strip removes the outside spaces.
- lower runs on that cleaned result.
- raw still refers to the original text.

Expected output: asha

Common mistake: Calling raw_name.strip() on its own does not update raw_name. Store the returned value.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Write a readable message with f-strings — walkthrough
- The f enables substitution.
- Each pair of braces reads a variable.

Expected output: Sam studied 15 minutes.

Common mistake: Without f, the braces are printed as ordinary characters.

Watch: [Functions and Variables](https://www.youtube.com/watch?v=JP7ITIXGpHk) — Harvard CS50 · David Malan (English). Watch the opening print, variables, numbers and strings examples first. Return to custom functions in Week 4.

### Compare values and understand booleans — walkthrough
- 39 does not reach 40.
- 39 is not equal to 100.

Expected output: False
False

Common mistake: score = 100 changes the value. score == 100 checks the value.

Watch: [Conditionals](https://www.youtube.com/watch?v=_b6NgY_pMdw) — Harvard CS50 · David Malan (English). Trace if, elif, else and boolean decisions. Pause and predict the branch before the lecturer runs it.

### Your first if block and indentation — walkthrough
- The initial message gives a default.
- The condition is True, so the indented assignment runs.
- print is outside the block and always runs.

Expected output: Passed

Common mistake: A missing colon causes SyntaxError. A block with no indentation causes IndentationError. Read the indicated line and the line just above it.

Watch: [Conditionals](https://www.youtube.com/watch?v=_b6NgY_pMdw) — Harvard CS50 · David Malan (English). Trace if, elif, else and boolean decisions. Pause and predict the branch before the lecturer runs it.

### Choose between two branches — walkthrough
- 22 >= 30 is False.
- Python skips the first body and runs else.

Expected output: Comfortable

Common mistake: Indenting else under the previous assignment breaks the block structure. Align it with its if.

Watch: [Conditionals](https://www.youtube.com/watch?v=_b6NgY_pMdw) — Harvard CS50 · David Malan (English). Trace if, elif, else and boolean decisions. Pause and predict the branch before the lecturer runs it.

### Multiple branches and their order — walkthrough
- The first condition succeeds.
- The remaining branches are skipped.

Expected output: A

Common mistake: Several separate if statements can all run. Use an if/elif/else chain when only one category should be chosen.

Watch: [Conditionals](https://www.youtube.com/watch?v=_b6NgY_pMdw) — Harvard CS50 · David Malan (English). Trace if, elif, else and boolean decisions. Pause and predict the branch before the lecturer runs it.

### Combine conditions with and, or and not — walkthrough
- Both True values make and return True.
- not True becomes False.

Expected output: True
False

Common mistake: Using or for a rule that requires both conditions grants entry too easily. Translate the words carefully.

Watch: [Conditionals](https://www.youtube.com/watch?v=_b6NgY_pMdw) — Harvard CS50 · David Malan (English). Trace if, elif, else and boolean decisions. Pause and predict the branch before the lecturer runs it.

Watch: [Conditionals](https://www.youtube.com/watch?v=_b6NgY_pMdw) — Harvard CS50 · David Malan (English). Trace if, elif, else and boolean decisions. Pause and predict the branch before the lecturer runs it.

Watch: [Conditionals](https://www.youtube.com/watch?v=_b6NgY_pMdw) — Harvard CS50 · David Malan (English). Trace if, elif, else and boolean decisions. Pause and predict the branch before the lecturer runs it.

Watch: [Conditionals](https://www.youtube.com/watch?v=_b6NgY_pMdw) — Harvard CS50 · David Malan (English). Trace if, elif, else and boolean decisions. Pause and predict the branch before the lecturer runs it.
