# Week 2: Expense calculator

Choose a condition or loop by tracing the data.

## Your assignment
- Accept a list of expenses.
- Handle an empty list and invalid amounts.
- Calculate total and category counts.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Choose the right branch
Return pass for a score of 40 or more, otherwise retry. Reject scores outside 0–100.

Check invalid input before normal branches. The boundary value 40 belongs to pass; using > would incorrectly reject it. Tests just below and at a boundary are especially useful.

Try exercises/w02-l1.py before reading reference/w02-l1.py.

## Trace a for loop
Sum only positive amounts from a list.

An accumulator starts at zero and changes on each matching item. Trace total after every iteration before running the loop. Empty input naturally keeps the initial value.

Try exercises/w02-l2.py before reading reference/w02-l2.py.

## A terminating while loop
Count the decimal digits of an integer, including zero.

A while loop must make progress toward its stopping condition. Integer division by 10 removes the final decimal digit. abs handles a negative sign; zero itself has one digit.

Try exercises/w02-l3.py before reading reference/w02-l3.py.
