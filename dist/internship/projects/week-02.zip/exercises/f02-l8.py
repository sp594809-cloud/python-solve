has_id = True
fee_paid = False
# Assign can_enter and needs_help.
