score = 75
# Assign grade using the stated rules.
