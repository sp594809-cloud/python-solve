def digit_count(number):
    # TODO: implement the task. Keep the function name and parameters.
    pass
