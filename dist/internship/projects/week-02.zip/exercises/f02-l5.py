score = 60
message = "Try again"
# Add your if block.
