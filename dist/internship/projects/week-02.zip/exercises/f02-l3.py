name = "Asha"
minutes = 30
# Create message.
