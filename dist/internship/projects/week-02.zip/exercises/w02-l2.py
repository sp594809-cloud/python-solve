def positive_total(amounts):
    # TODO: implement the task. Keep the function name and parameters.
    pass
