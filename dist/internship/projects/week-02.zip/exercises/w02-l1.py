def result(score):
    # TODO: implement the task. Keep the function name and parameters.
    pass
