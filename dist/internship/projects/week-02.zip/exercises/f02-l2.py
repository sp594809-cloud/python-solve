raw_name = "  Krish  "
# Create clean_name.
