score = 40
# Create passed and perfect.
