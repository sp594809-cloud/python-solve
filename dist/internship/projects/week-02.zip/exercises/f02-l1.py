word = "PYTHON"
# Assign first and middle.
