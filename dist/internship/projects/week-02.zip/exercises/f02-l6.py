temperature = 35
# Create advice using if and else.
