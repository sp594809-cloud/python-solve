def add_tax(prices):
    for i in range(len(prices)):
        prices[i] *= 1.1
    return prices
