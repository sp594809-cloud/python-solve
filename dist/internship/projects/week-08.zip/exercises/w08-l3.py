def word_summary(text):
    # TODO: implement the task. Keep the function name and parameters.
    pass
