import unittest
from project import summarize
class Summary(unittest.TestCase):
 def test_repeated(self):self.assertEqual(summarize("AI ai Python"),{"total":3,"unique":2})
 def test_empty(self):self.assertEqual(summarize(" "),{"total":0,"unique":0})
if __name__=="__main__":unittest.main()
