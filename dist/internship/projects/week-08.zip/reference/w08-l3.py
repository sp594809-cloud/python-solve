def word_summary(text):
    words = text.lower().split()
    return {"total": len(words), "unique": len(set(words))}
