def add_tax(prices):
    return [round(price * 1.1, 2) for price in prices]
