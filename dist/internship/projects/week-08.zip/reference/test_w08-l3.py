def word_summary(text):
    words = text.lower().split()
    return {"total": len(words), "unique": len(set(words))}

assert word_summary("AI ai Python")=={"total":3,"unique":2}
assert word_summary("  ")=={"total":0,"unique":0}
assert word_summary("a\nb")["total"]==2
print("Checks passed")
