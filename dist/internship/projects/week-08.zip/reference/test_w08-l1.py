def palindrome(text):
    clean = text.replace(" ", "").lower()
    return clean == clean[::-1]

assert palindrome("Never odd or even") is True
assert palindrome("python") is False
assert palindrome("") is True
print("Checks passed")
