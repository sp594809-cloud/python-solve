def add_tax(prices):
    return [round(price * 1.1, 2) for price in prices]

assert add_tax([10,20])==[11,22]
p=[10]; add_tax(p); assert p==[10]
assert add_tax([])==[]
print("Checks passed")
