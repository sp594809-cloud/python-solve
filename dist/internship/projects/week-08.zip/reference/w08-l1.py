def palindrome(text):
    clean = text.replace(" ", "").lower()
    return clean == clean[::-1]
