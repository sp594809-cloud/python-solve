# Week 8: Tested Python package

Write code that another person can run and review.

## Your assignment
- Create a README with setup and examples.
- Add passing tests and a regression test for a fixed bug.
- Make at least three meaningful Git commits locally.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py "AI ai Python"
```

Run python -m unittest. Start local history with git init, git add ., git commit -m "Add working summary". Make a change and test before another commit. GitHub upload requires your own account.

## Tests that reveal a bug
Return whether a string is a palindrome after removing spaces and normalizing case.

Test ordinary inputs and counterexamples. A result that is always True passes positive examples but fails a negative case. State which punctuation rules apply; here only spaces and case are ignored.

Try exercises/w08-l1.py before reading reference/w08-l1.py.

## Debug from a failing assertion
Fix the function so it never changes its caller’s list.

Assignment copies a reference, not the list. If a helper must preserve input, copy before mutation or build a new result. Tests should inspect the original after the call.

Try exercises/w08-l2.py before reading reference/w08-l2.py.

## Package a useful command
Summarize words with total and unique counts.

A package should expose a small, predictable interface. Keep the calculation separate from a CLI so tests do not need to interact with input prompts. The README should state the normalization rules.

Try exercises/w08-l3.py before reading reference/w08-l3.py.
