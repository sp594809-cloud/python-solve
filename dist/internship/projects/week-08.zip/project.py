def summarize(text):
    words=text.lower().split();return {"total":len(words),"unique":len(set(words))}
if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser();p.add_argument("text");args=p.parse_args();print(summarize(args.text))
