from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator
from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
app=FastAPI(title="AI support desk — learning demo")
TRAIN=["invoice payment","billing refund","refund invoice","payment charge","login password","account login","reset password","login access"]
LABELS=["billing"]*4+["technical"]*4
model=make_pipeline(TfidfVectorizer(),LogisticRegression(random_state=42)).fit(TRAIN,LABELS)
NOTES=[{"id":"billing-1","text":"For an invoice or payment issue, contact billing with the invoice number."},{"id":"login-1","text":"For login password issues, use the password reset option. Never share your password."}]
class Message(BaseModel):
    message:str=Field(min_length=3,max_length=500)
    @field_validator("message")
    @classmethod
    def clean(cls,v):
        if not 3<=len(v.strip())<=500:raise ValueError("Use 3–500 characters")
        return v.strip()
def evidence(query):
    words=set(query.lower().split());scores=[(len(words & set(n["text"].lower().split())),n) for n in NOTES];score,note=max(scores,key=lambda x:x[0]);return note if score else None
@app.get("/")
def home():return FileResponse(Path(__file__).with_name("index.html"))
@app.get("/health")
def health():return {"ready":True,"mode":"demo"}
@app.post("/support")
def support(data:Message):return {"category":str(model.predict([data.message])[0]),"evidence":evidence(data.message),"disclaimer":"Demo model trained on eight synthetic messages. Verify the source; no LLM is used."}
