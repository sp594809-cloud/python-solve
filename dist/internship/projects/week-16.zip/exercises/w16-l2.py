def support_response(category, evidence):
    # TODO: implement the task. Keep the function name and parameters.
    pass
