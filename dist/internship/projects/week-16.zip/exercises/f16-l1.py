def portfolio_files(files):
    pass
