def portfolio_report(features, tests, next_step):
    # TODO: implement the task. Keep the function name and parameters.
    pass
