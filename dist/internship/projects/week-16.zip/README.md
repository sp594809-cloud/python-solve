# Week 16: AI support desk

Combine a Python API, webpage and measured small model.

## Your assignment
- Run the included AI support-desk starter.
- Add your own feature and a test for it.
- Record a demo and explain architecture, failure cases and next steps.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run on a laptop (Python 3.11+)

```sh
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m unittest test_app.py
python -m uvicorn app:app --reload
```

Open http://127.0.0.1:8000 and /docs. Serve the frontend from this API; opening index.html directly will not make fetch work. Stop with Ctrl+C.

Local learning demo: no user accounts, persistent database, rate limits or production monitoring. Use only sample data. Do not expose private data or treat this as a production service.

## Capstone input contract
Validate a support message: trimmed text of 3–500 characters, otherwise ValueError.

Keep the capstone’s HTTP boundary small and explicit. A message length limit helps prevent accidental oversized requests. It does not replace authentication, rate limits or a production abuse strategy.

Try exercises/w16-l1.py before reading reference/w16-l1.py.

## Combine model and evidence
Build a response with category, evidence and demo disclaimer.

The model predicts a category; retrieval supplies stored evidence. These are separate operations with separate failure cases. The UI should say when no source matched and make the demo limitation visible.

Try exercises/w16-l2.py before reading reference/w16-l2.py.

## Explain your project with measurable facts
Return a portfolio report with feature count, passing-test count and next step. Reject negative counts.

A useful internship portfolio shows what you built, how to run it, tests and limitations. Passing these lessons is practice evidence, not proof of job readiness. Record a demo, read unfamiliar code and explain decisions without copying the reference.

Try exercises/w16-l3.py before reading reference/w16-l3.py.
