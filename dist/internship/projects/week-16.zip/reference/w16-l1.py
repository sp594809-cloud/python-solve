def support_message(payload):
    message=payload.get("message")
    if not isinstance(message,str) or not 3<=len(message.strip())<=500:
        raise ValueError("message must be 3–500 characters")
    return message.strip()
