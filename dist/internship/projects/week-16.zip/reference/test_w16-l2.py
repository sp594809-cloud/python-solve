def support_response(category, evidence):
    return {"category":category,"evidence":evidence,"disclaimer":"Demo model; check the source."}

assert support_response("billing",None)["category"]=="billing"
e={"source":"n1","answer":"Read this"};assert support_response("technical",e)["evidence"]==e
assert "Demo" in support_response("billing",None)["disclaimer"]
print("Checks passed")
