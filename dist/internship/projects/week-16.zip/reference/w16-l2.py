def support_response(category, evidence):
    return {"category":category,"evidence":evidence,"disclaimer":"Demo model; check the source."}
