def support_message(payload):
    message=payload.get("message")
    if not isinstance(message,str) or not 3<=len(message.strip())<=500:
        raise ValueError("message must be 3–500 characters")
    return message.strip()

assert support_message({"message":"  login help  "})=="login help"
try:
 support_message({"message":"hi"})
except ValueError:
 pass
else:
 raise AssertionError("Expected ValueError")
try:
 support_message({"message":"a"*501})
except ValueError:
 pass
else:
 raise AssertionError("Expected ValueError")
print("Checks passed")
