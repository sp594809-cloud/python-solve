def portfolio_files(files):
    return {"README.md","app.py","test_app.py"}.issubset(set(files))

assert portfolio_files(["README.md","app.py","test_app.py"]) is True
assert portfolio_files(["README.md","app.py"]) is False
assert portfolio_files(["README.md","app.py","test_app.py","notes.txt"]) is True
print("Checks passed")
