def portfolio_report(features, tests, next_step):
    if features<0 or tests<0:
        raise ValueError("counts must be nonnegative")
    return {"features":features,"tests":tests,"next_step":next_step.strip()}

assert portfolio_report(3,12," add auth ")=={"features":3,"tests":12,"next_step":"add auth"}
assert portfolio_report(0,0,"write tests")["tests"]==0
try:
 portfolio_report(-1,2,"x")
except ValueError:
 pass
else:
 raise AssertionError("Expected ValueError")
print("Checks passed")
