def portfolio_report(features, tests, next_step):
    if features<0 or tests<0:
        raise ValueError("counts must be nonnegative")
    return {"features":features,"tests":tests,"next_step":next_step.strip()}
