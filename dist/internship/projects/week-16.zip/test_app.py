import unittest
from fastapi.testclient import TestClient
from app import app
class Support(unittest.TestCase):
    def test_contract(self):
        c=TestClient(app)
        self.assertEqual(c.post('/support',json={"message":"hi"}).status_code,422)
        self.assertEqual(c.post('/support',json={"message":"a"*501}).status_code,422)
        d=c.post('/support',json={"message":"invoice payment"}).json()
        self.assertEqual(d['category'],'billing');self.assertEqual(d['evidence']['id'],'billing-1')
        d=c.post('/support',json={"message":"login password"}).json();self.assertEqual(d['category'],'technical')
        self.assertIsNone(c.post('/support',json={"message":"weather outside"}).json()['evidence'])
        self.assertEqual(c.get('/').status_code,200)
if __name__=='__main__':unittest.main()
