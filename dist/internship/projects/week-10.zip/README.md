# Week 10: Task API

Distinguish input validation, status codes and API business logic.

## Your assignment
- Run the downloaded FastAPI example on your laptop.
- Add a task endpoint and reject blank titles.
- Exercise GET and POST routes and record responses.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run on a laptop (Python 3.11+)

```sh
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m unittest test_app.py
python -m uvicorn app:app --reload
```

Open http://127.0.0.1:8000 and /docs. Serve the frontend from this API; opening index.html directly will not make fetch work. Stop with Ctrl+C.

Local learning demo: no user accounts, persistent database, rate limits or production monitoring. Use only sample data. Do not expose private data or treat this as a production service.

## Validate a request body
Normalize a task title, rejecting non-text or empty titles.

HTTP requests carry untrusted data. Validation belongs on the server even when a form checks input. Here we test pure business logic; the downloadable FastAPI project uses it inside a real route.

Try exercises/w10-l1.py before reading reference/w10-l1.py.

## HTTP status and missing records
Return (200, task) when found, otherwise (404, error).

Status codes communicate the result separately from response data. A missing record is not an empty successful response. Avoid confusing a list position with a record ID.

Try exercises/w10-l2.py before reading reference/w10-l2.py.

## Pagination as an API contract
Return a page slice using zero-based offset and positive limit. Reject invalid ranges.

Pagination keeps responses bounded. Document whether your offset starts at zero. Negative offsets in Python have a meaning, but they are invalid for this API contract.

Try exercises/w10-l3.py before reading reference/w10-l3.py.
