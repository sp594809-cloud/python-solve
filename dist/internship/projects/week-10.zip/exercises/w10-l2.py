def find_task(tasks, task_id):
    # TODO: implement the task. Keep the function name and parameters.
    pass
