def page(items, offset, limit):
    # TODO: implement the task. Keep the function name and parameters.
    pass
