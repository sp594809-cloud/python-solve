def find_task(tasks, task_id):
    for task in tasks:
        if task["id"] == task_id:
            return (200, task)
    return (404, {"error":"not found"})

assert find_task([{"id":4,"title":"Read"}],4)==(200,{"id":4,"title":"Read"})
assert find_task([{"id":4}],1)[0]==404
assert find_task([],1)==(404,{"error":"not found"})
print("Checks passed")
