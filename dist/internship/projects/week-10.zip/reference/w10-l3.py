def page(items, offset, limit):
    if offset < 0 or limit <= 0:
        raise ValueError("invalid range")
    return items[offset:offset+limit]
