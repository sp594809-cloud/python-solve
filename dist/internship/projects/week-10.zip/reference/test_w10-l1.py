def task_title(payload):
    title = payload.get("title")
    if not isinstance(title, str) or not title.strip():
        raise ValueError("title required")
    return title.strip()

assert task_title({"title":"  Read  "})=="Read"
try:
 task_title({"title":" "})
except ValueError:
 pass
else:
 raise AssertionError("Expected ValueError")
try:
 task_title({"title":12})
except ValueError:
 pass
else:
 raise AssertionError("Expected ValueError")
print("Checks passed")
