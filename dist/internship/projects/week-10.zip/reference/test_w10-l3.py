def page(items, offset, limit):
    if offset < 0 or limit <= 0:
        raise ValueError("invalid range")
    return items[offset:offset+limit]

assert page([1,2,3,4],1,2)==[2,3]
assert page([1],5,2)==[]
for offset,limit in [(-1,2),(0,0)]:
 try:
  page([],offset,limit)
 except ValueError:
  pass
 else:
  raise AssertionError("Expected ValueError")
print("Checks passed")
