def task_title(payload):
    title = payload.get("title")
    if not isinstance(title, str) or not title.strip():
        raise ValueError("title required")
    return title.strip()
