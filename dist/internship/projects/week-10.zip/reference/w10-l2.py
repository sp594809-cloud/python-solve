def find_task(tasks, task_id):
    for task in tasks:
        if task["id"] == task_id:
            return (200, task)
    return (404, {"error":"not found"})
