def withdraw(balance, amount):
    if amount < 0 or amount > balance:
        raise ValueError("invalid amount")
    return balance - amount

assert withdraw(100,30)==70
assert withdraw(100,0)==100
for a in [-1,101]:
 try:
  withdraw(100,a)
 except ValueError:
  pass
 else:
  raise AssertionError("Expected ValueError")
print("Checks passed")
