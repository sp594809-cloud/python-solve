def round_trip(path, text):
    with open(path,"w",encoding="utf-8") as file:
        file.write(text)
    with open(path,encoding="utf-8") as file:
        return file.read()

assert round_trip("note-a.txt","hello")=="hello"
assert round_trip("note-b.txt","નમસ્તે")=="નમસ્તે"
round_trip("note-c.txt","longer");assert round_trip("note-c.txt","x")=="x"
print("Checks passed")
