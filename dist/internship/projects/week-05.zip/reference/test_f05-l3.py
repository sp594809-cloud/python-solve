import math
root = math.sqrt(81)

assert root==9
assert math.sqrt(16)==4
print("Checks passed")
