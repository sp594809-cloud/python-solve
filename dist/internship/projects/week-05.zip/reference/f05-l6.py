def summarize_scores(scores):
    return {"count":len(scores),"total":sum(scores)}
