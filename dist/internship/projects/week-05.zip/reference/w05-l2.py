def save_note(path, text):
    with open(path, "w", encoding="utf-8") as file:
        file.write(text)
    with open(path, encoding="utf-8") as file:
        return file.read()
