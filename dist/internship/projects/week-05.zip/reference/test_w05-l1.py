def positive_integer(text):
    try:
        value = int(text)
    except (ValueError, TypeError):
        return None
    return value if value > 0 else None

assert positive_integer("12")==12
assert positive_integer("abc") is None
assert positive_integer("0") is None and positive_integer("-2") is None
print("Checks passed")
