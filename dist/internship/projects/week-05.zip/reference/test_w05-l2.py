def save_note(path, text):
    with open(path, "w", encoding="utf-8") as file:
        file.write(text)
    with open(path, encoding="utf-8") as file:
        return file.read()

assert save_note("note.txt","learn loops")=="learn loops"
assert save_note("note.txt","new")=="new"
assert save_note("unicode.txt","નમસ્તે")=="નમસ્તે"
print("Checks passed")
