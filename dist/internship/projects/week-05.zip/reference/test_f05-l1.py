def parse_age(text):
    try:
        return int(text)
    except ValueError:
        return None

assert parse_age("18")==18
assert parse_age("hello") is None
assert parse_age(" 20 ")==20
print("Checks passed")
