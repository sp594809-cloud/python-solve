def positive_integer(text):
    try:
        value = int(text)
    except (ValueError, TypeError):
        return None
    return value if value > 0 else None
