from pathlib import Path
def filename(path_text):
    return Path(path_text).name
