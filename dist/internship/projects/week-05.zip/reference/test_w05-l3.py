def read_notes(path):
    try:
        with open(path, encoding="utf-8") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

assert read_notes("missing-file.txt")==[]
open("lines.txt","w").write("a\nb\n"); assert read_notes("lines.txt")==["a","b"]
open("empty.txt","w").close(); assert read_notes("empty.txt")==[]
print("Checks passed")
