def summarize_scores(scores):
    return {"count":len(scores),"total":sum(scores)}

assert summarize_scores([5,7])=={"count":2,"total":12}
assert summarize_scores([])=={"count":0,"total":0}
a=[3];summarize_scores(a);assert a==[3]
print("Checks passed")
