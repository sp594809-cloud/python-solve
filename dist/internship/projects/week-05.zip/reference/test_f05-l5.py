from pathlib import Path
def filename(path_text):
    return Path(path_text).name

assert filename("notes/week5.txt")=="week5.txt"
assert filename("readme.md")=="readme.md"
assert filename("notes/my draft.txt")=="my draft.txt"
print("Checks passed")
