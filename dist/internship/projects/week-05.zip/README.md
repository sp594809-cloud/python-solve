# Week 5: Study notes CLI

Handle bad input and save useful information.

## Your assignment
- Save notes in a text file.
- Read them back after restarting.
- Handle a missing file without crashing.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Read a traceback from the bottom
Define parse_age(text): return int(text), or None when conversion raises ValueError.

A traceback shows the calls that led to a failure. Start at its last line to identify the exception type and message. Then inspect the referenced line in your code.

Catch a specific error you know how to handle. ValueError means the type may be acceptable but the value cannot be used as requested. Do not use a broad except to hide every failure.

Try exercises/f05-l1.py before reading reference/f05-l1.py.

## Raise an error for an invalid request
Define withdraw(balance, amount), rejecting a negative amount or an amount greater than balance.

Sometimes your function should reject a request instead of returning an ordinary value. raise ValueError communicates a broken input rule to the caller.

Validation belongs before state changes. A rejected withdrawal should not partially change data. Here we return a new balance rather than modifying an account object.

Try exercises/f05-l2.py before reading reference/f05-l2.py.

## Import a module instead of rewriting it
Import math and store the square root of 81 in root.

A module groups reusable Python code. import makes that module available under a name. Access its features using a dot, such as math.sqrt.

The standard library ships with Python. Third-party packages are installed separately. Prefer a well-tested library when it already solves your problem.

Try exercises/f05-l3.py before reading reference/f05-l3.py.

## Write and read a text file
Define round_trip(path,text): write UTF-8 text, then read and return it.

A file keeps data beyond a variable’s lifetime. open needs a path and mode: w writes and replaces existing content; r reads it.

A with block closes the file even when an error occurs. Encoding UTF-8 supports Gujarati and other scripts. Browser runtime files are temporary: downloading code does not download files it created.

Try exercises/f05-l4.py before reading reference/f05-l4.py.

## Use paths without manual slash joining
Define filename(path_text) returning just the final filename using pathlib.Path.

A path locates a file or directory. pathlib represents a path as an object, with operations such as name, suffix and parent.

Working directory matters: a relative path starts from the program’s current directory. Read FileNotFoundError as a path problem to investigate, not proof that the file never existed.

Try exercises/f05-l5.py before reading reference/f05-l5.py.

## Split data from the user interface
Define summarize_scores(scores) returning count and total without printing or reading input.

A command-line program has separate concerns: obtain input, calculate a result, and present it. Keep the calculation in a function that receives ordinary data.

This makes the same logic usable in a notebook, test, webpage or API. input prompts belong at the outer boundary, not inside a calculation a server needs to call.

Try exercises/f05-l6.py before reading reference/f05-l6.py.

## Exceptions with useful defaults
Parse a positive integer, returning None for invalid or nonpositive text.

Catch the exception you expect, not every possible failure. int raises ValueError for text such as abc or 2.5. A valid integer can still violate your business rule.

Try exercises/w05-l1.py before reading reference/w05-l1.py.

## Write and read a text file
Save a note in UTF-8 and return its content after reading it back.

A file survives beyond a function call. with closes handles even when an exception occurs. Encoding should be explicit so names and non-English text round-trip correctly.

Try exercises/w05-l2.py before reading reference/w05-l2.py.

## Handle a missing file
Return a file’s lines without trailing newlines, or an empty list if it is missing.

Missing data can be a normal situation. FileNotFoundError is specific; catching it should not hide permission errors or other bugs. splitlines handles the newline boundaries.

Try exercises/w05-l3.py before reading reference/w05-l3.py.

### Read a traceback from the bottom — walkthrough
- Conversion fails for the supplied text.
- The matching except block provides the chosen fallback.

Expected output: None

Common mistake: except: can also hide bugs such as a misspelled variable. Catch the error you intend to recover from.

Watch: [Exceptions](https://www.youtube.com/watch?v=LW7g1169v7w) — Harvard CS50 · David Malan (English). Read errors and practise targeted try/except blocks.

### Raise an error for an invalid request — walkthrough
- Check the input rule first.
- The valid path returns normally.

Expected output: 2

Common mistake: Returning zero for every invalid request makes a failure look like a successful empty balance. Use an explicit error contract.

Watch: [Exceptions](https://www.youtube.com/watch?v=LW7g1169v7w) — Harvard CS50 · David Malan (English). Read errors and practise targeted try/except blocks.

### Import a module instead of rewriting it — walkthrough
- The import makes math available.
- sqrt calculates the nonnegative square root.

Expected output: 7.0

Common mistake: Naming your own file math.py can shadow the standard library module. Use a descriptive project filename.

Watch: [Libraries](https://www.youtube.com/watch?v=MztLZWibctI) — Harvard CS50 · David Malan (English). Follow imports, pip, JSON and the main-module pattern. Practise with the supplied local fixtures before live APIs.

### Write and read a text file — walkthrough
- The first with writes text and closes the handle.
- The second opens the same path for reading.

Expected output: Keep practising

Common mistake: Mode w replaces existing contents. Use a when you deliberately want to append.

Watch: [File I/O](https://www.youtube.com/watch?v=KD-Yoel6EVQ) — Harvard CS50 · David Malan (English). Follow text files and CSV examples; try one Unicode value yourself.

### Use paths without manual slash joining — walkthrough
- The / operator joins path components.
- name returns the final component; suffix returns its extension.

Expected output: week5.txt
.txt

Common mistake: A filename copied from another device may not exist here. Check the current directory and actual uploaded file location.

Watch: [File I/O](https://www.youtube.com/watch?v=KD-Yoel6EVQ) — Harvard CS50 · David Malan (English). Follow text files and CSV examples; try one Unicode value yourself.

### Split data from the user interface — walkthrough
- The function only calculates.
- The caller decides how to display the answer.

Expected output: Total: 7

Common mistake: A function that asks for input cannot be easily tested with a supplied list. Accept the list as a parameter.

Watch: [Exceptions](https://www.youtube.com/watch?v=LW7g1169v7w) — Harvard CS50 · David Malan (English). Read errors and practise targeted try/except blocks.

Watch: [Exceptions](https://www.youtube.com/watch?v=LW7g1169v7w) — Harvard CS50 · David Malan (English). Read errors and practise targeted try/except blocks.

Watch: [File I/O](https://www.youtube.com/watch?v=KD-Yoel6EVQ) — Harvard CS50 · David Malan (English). Follow text files and CSV examples; try one Unicode value yourself.

Watch: [File I/O](https://www.youtube.com/watch?v=KD-Yoel6EVQ) — Harvard CS50 · David Malan (English). Follow text files and CSV examples; try one Unicode value yourself.
