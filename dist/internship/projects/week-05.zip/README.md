# Week 5: Study notes CLI

Handle bad input and save useful information.

## Your assignment
- Save notes in a text file.
- Read them back after restarting.
- Handle a missing file without crashing.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Exceptions with useful defaults
Parse a positive integer, returning None for invalid or nonpositive text.

Catch the exception you expect, not every possible failure. int raises ValueError for text such as abc or 2.5. A valid integer can still violate your business rule.

Try exercises/w05-l1.py before reading reference/w05-l1.py.

## Write and read a text file
Save a note in UTF-8 and return its content after reading it back.

A file survives beyond a function call. with closes handles even when an exception occurs. Encoding should be explicit so names and non-English text round-trip correctly.

Try exercises/w05-l2.py before reading reference/w05-l2.py.

## Handle a missing file
Return a file’s lines without trailing newlines, or an empty list if it is missing.

Missing data can be a normal situation. FileNotFoundError is specific; catching it should not hide permission errors or other bugs. splitlines handles the newline boundaries.

Try exercises/w05-l3.py before reading reference/w05-l3.py.
