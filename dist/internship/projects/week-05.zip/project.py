from pathlib import Path
import argparse
def read(path):return Path(path).read_text(encoding="utf-8") if Path(path).exists() else ""
def save(path,note):
    with open(path,"a",encoding="utf-8") as f:f.write(note+"\n")
if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--add");parser.add_argument("--file",default="notes.txt");args=parser.parse_args()
    if args.add:save(args.file,args.add)
    print(read(args.file) or "No notes yet. Use --add 'your note'.")
