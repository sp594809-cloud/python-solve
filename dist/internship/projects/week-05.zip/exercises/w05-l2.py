def save_note(path, text):
    # TODO: implement the task. Keep the function name and parameters.
    pass
