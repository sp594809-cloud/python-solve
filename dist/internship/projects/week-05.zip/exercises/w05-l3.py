def read_notes(path):
    # TODO: implement the task. Keep the function name and parameters.
    pass
