def summarize_scores(scores):
    pass
