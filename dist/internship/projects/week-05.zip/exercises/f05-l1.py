def parse_age(text):
    # Catch ValueError only.
    pass
