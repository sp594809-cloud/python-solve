def round_trip(path, text):
    pass
