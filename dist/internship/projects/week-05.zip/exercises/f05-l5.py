from pathlib import Path
def filename(path_text):
    pass
