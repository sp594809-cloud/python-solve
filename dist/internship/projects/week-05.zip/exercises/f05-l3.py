# Import math and create root.
