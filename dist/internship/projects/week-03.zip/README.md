# Week 3: Contact book

Choose lists, dictionaries and sets for the job.

## Your assignment
- Add, find and update contacts.
- Prevent duplicate names.
- Test missing contacts and empty data.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Lists and safe iteration
Return the names longer than three characters, without changing the original list.

Lists preserve order. Create a new result instead of removing items while iterating. Removing from the same list can skip the next item as indexes move.

Try exercises/w03-l1.py before reading reference/w03-l1.py.

## Dictionaries and counting
Count each category in an expense list.

A dictionary maps a key to a value. get(key, 0) supplies an initial count for a new key. This avoids a separate branch for the first occurrence.

Try exercises/w03-l2.py before reading reference/w03-l2.py.

## Sets and uniqueness
Return unique lowercase names in sorted order.

A set removes duplicates but does not provide a useful display order. Normalize case before deduplication, then sort for predictable output. This is a small data-cleaning pipeline.

Try exercises/w03-l3.py before reading reference/w03-l3.py.
