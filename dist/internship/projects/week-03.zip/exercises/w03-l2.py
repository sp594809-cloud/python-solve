def category_counts(categories):
    # TODO: implement the task. Keep the function name and parameters.
    pass
