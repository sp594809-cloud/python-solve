def long_names(names):
    # TODO: implement the task. Keep the function name and parameters.
    pass
