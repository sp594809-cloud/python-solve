class ContactBook:
    def __init__(self):self.contacts={}
    def add(self,name,email):
        key=name.strip().lower()
        if not key or key in self.contacts:raise ValueError("Missing or duplicate name")
        self.contacts[key]=email
    def find(self,name):return self.contacts.get(name.strip().lower())
    def update(self,name,email):
        key=name.strip().lower()
        if key not in self.contacts:raise KeyError(key)
        self.contacts[key]=email
if __name__=="__main__":
    book=ContactBook();book.add("Asha","asha@example.test");print(book.find("ASHA"))
