def category_counts(categories):
    counts = {}
    for category in categories:
        counts[category] = counts.get(category, 0) + 1
    return counts

assert category_counts(["food","travel","food"])=={"food":2,"travel":1}
assert category_counts([])=={}
assert category_counts(["books"])=={"books":1}
print("Checks passed")
