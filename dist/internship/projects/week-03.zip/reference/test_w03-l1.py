def long_names(names):
    return [name for name in names if len(name) > 3]

assert long_names(["Li","Asha","Krish"])==["Asha","Krish"]
assert long_names([])==[]
original=["Li","Asha"]; long_names(original); assert original==["Li","Asha"]
print("Checks passed")
