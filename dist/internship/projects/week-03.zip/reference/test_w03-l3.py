def unique_names(names):
    return sorted({name.strip().lower() for name in names})

assert unique_names(["Asha"," asha ","SAM"])==["asha","sam"]
assert unique_names([])==[]
assert unique_names(["z","a"])==["a","z"]
print("Checks passed")
