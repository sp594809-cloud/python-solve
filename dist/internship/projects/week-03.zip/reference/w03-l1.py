def long_names(names):
    return [name for name in names if len(name) > 3]
