def category_counts(categories):
    counts = {}
    for category in categories:
        counts[category] = counts.get(category, 0) + 1
    return counts
