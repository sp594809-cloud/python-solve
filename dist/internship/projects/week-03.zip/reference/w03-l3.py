def unique_names(names):
    return sorted({name.strip().lower() for name in names})
