def status_message(status, count):
    if status != 200:
        return "Could not load tasks"
    return "No tasks yet" if count == 0 else f"{count} tasks loaded"
