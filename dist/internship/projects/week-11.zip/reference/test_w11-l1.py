def status_message(status, count):
    if status != 200:
        return "Could not load tasks"
    return "No tasks yet" if count == 0 else f"{count} tasks loaded"

assert status_message(200,0)=="No tasks yet"
assert status_message(200,3)=="3 tasks loaded"
assert status_message(500,3)=="Could not load tasks"
print("Checks passed")
