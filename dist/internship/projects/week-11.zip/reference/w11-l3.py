def complete_task(tasks, task_id):
    return [dict(task, done=True) if task["id"] == task_id else dict(task) for task in tasks]
