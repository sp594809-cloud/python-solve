def complete_task(tasks, task_id):
    return [dict(task, done=True) if task["id"] == task_id else dict(task) for task in tasks]

assert complete_task([{"id":9,"done":False}],9)==[{"id":9,"done":True}]
assert complete_task([{"id":9,"done":False}],1)==[{"id":9,"done":False}]
a=[{"id":9,"done":False}];complete_task(a,9);assert a[0]["done"] is False
print("Checks passed")
