import html
def safe_text(text):
    return html.escape(text, quote=True)

assert safe_text("<img>")=="&lt;img&gt;"
assert safe_text("A&B")=="A&amp;B"
assert safe_text(chr(34)+chr(39))=="&quot;&#x27;"
print("Checks passed")
