def view_state(loading, error, items):
    if loading: return "loading"
    if error: return "error"
    return "ready" if items else "empty"

assert view_state(True,True,[])=="loading"
assert view_state(False,True,[1])=="error"
assert view_state(False,False,[])=="empty" and view_state(False,False,[1])=="ready"
print("Checks passed")
