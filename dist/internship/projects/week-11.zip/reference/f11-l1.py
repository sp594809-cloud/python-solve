def view_state(loading, error, items):
    if loading: return "loading"
    if error: return "error"
    return "ready" if items else "empty"
