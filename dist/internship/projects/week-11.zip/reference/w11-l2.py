import html
def safe_text(text):
    return html.escape(text, quote=True)
