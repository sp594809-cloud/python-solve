# Week 11: Task dashboard

Move data between a page and a Python service.

## Your assignment
- Use fetch and show loading, success and error states.
- Render server responses safely using textContent.
- Test the dashboard with the local API running.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run on a laptop (Python 3.11+)

```sh
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m unittest test_app.py
python -m uvicorn app:app --reload
```

Open http://127.0.0.1:8000 and /docs. Serve the frontend from this API; opening index.html directly will not make fetch work. Stop with Ctrl+C.

Local learning demo: no user accounts, persistent database, rate limits or production monitoring. Use only sample data. Do not expose private data or treat this as a production service.

## Separate response states
Map a status and task count to a useful frontend message.

A frontend needs loading, success, empty and error states. This Python helper models the response-to-message decision; the project kit implements fetch in JavaScript. Never show success when the HTTP request failed.

Try exercises/w11-l1.py before reading reference/w11-l1.py.

## Render text safely
Escape &, <, >, quotes and apostrophes for an HTML text fragment.

Prefer textContent in JavaScript. This exercise shows why interpolating arbitrary text into HTML is dangerous. Escaping is context-specific; this helper is not a general URL or script sanitizer.

Try exercises/w11-l2.py before reading reference/w11-l2.py.

## Keep stable identity when updating
Return a new list with the matching task marked done; preserve other records and input.

UI state updates should use stable IDs, not current positions. Returning new records avoids changing shared data unexpectedly. A missing ID leaves the data unchanged.

Try exercises/w11-l3.py before reading reference/w11-l3.py.
