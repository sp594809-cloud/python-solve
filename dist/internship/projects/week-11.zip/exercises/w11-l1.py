def status_message(status, count):
    # TODO: implement the task. Keep the function name and parameters.
    pass
