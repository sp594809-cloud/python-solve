def view_state(loading, error, items):
    pass
