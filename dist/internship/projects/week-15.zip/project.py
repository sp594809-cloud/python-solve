NOTES=[{"id":"n1","text":"Lists preserve order and allow duplicates"},{"id":"n2","text":"Sets contain unique values"},{"id":"n3","text":"Functions return values to callers"}]
def search(query):
    words=set(query.lower().split());ranked=[]
    for note in NOTES:
        score=len(words & set(note["text"].lower().split()))
        if score:ranked.append((-score,note["id"],note["text"]))
    return [{"source":source,"text":text} for _,source,text in sorted(ranked)]
if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser();p.add_argument("query",nargs="?",default="lists order");print(search(p.parse_args().query) or "No matching source")
