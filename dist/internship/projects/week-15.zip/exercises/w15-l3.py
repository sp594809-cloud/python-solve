def review_ready(tests_pass, can_explain, contains_secret):
    # TODO: implement the task. Keep the function name and parameters.
    pass
