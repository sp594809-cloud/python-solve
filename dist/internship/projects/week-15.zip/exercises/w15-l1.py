def search_notes(query, notes):
    # TODO: implement the task. Keep the function name and parameters.
    pass
