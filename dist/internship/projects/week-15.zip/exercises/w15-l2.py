def grounded_answer(note_id, notes):
    # TODO: implement the task. Keep the function name and parameters.
    pass
