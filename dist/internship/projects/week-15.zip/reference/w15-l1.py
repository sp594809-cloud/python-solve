def search_notes(query, notes):
    words=set(query.lower().split())
    ranked=[]
    for note in notes:
        score=len(words & set(note["text"].lower().split()))
        if score:
            ranked.append((-score,note["id"]))
    return [note_id for _,note_id in sorted(ranked)]
