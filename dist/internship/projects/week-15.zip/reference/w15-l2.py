def grounded_answer(note_id, notes):
    for note in notes:
        if note["id"]==note_id:
            return {"answer":note["text"], "source":note_id}
    return {"answer":"No matching note", "source":None}
