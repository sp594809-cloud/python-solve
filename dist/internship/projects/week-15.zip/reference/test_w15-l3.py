def review_ready(tests_pass, can_explain, contains_secret):
    return bool(tests_pass and can_explain and not contains_secret)

assert review_ready(True,True,False) is True
assert review_ready(True,False,False) is False
assert review_ready(True,True,True) is False and review_ready(False,True,False) is False
print("Checks passed")
