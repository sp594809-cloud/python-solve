def search_notes(query, notes):
    words=set(query.lower().split())
    ranked=[]
    for note in notes:
        score=len(words & set(note["text"].lower().split()))
        if score:
            ranked.append((-score,note["id"]))
    return [note_id for _,note_id in sorted(ranked)]

assert search_notes("python lists",[{"id":"b","text":"python"},{"id":"a","text":"python lists"}])==["a","b"]
assert search_notes("weather",[{"id":"a","text":"python"}])==[]
assert search_notes("python",[{"id":"b","text":"Python"},{"id":"a","text":"python"}])==["a","b"]
print("Checks passed")
