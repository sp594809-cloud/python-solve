def review_ready(tests_pass, can_explain, contains_secret):
    return bool(tests_pass and can_explain and not contains_secret)
