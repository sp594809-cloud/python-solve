def grounded_answer(note_id, notes):
    for note in notes:
        if note["id"]==note_id:
            return {"answer":note["text"], "source":note_id}
    return {"answer":"No matching note", "source":None}

assert grounded_answer("a",[{"id":"a","text":"Lists keep order"}])=={"answer":"Lists keep order","source":"a"}
assert grounded_answer("x",[])=={"answer":"No matching note","source":None}
assert grounded_answer("b",[{"id":"b","text":"Stored evidence."}])["answer"]=="Stored evidence."
print("Checks passed")
