def greeting(name, score):
    return f"Hello {name.strip()}, your score is {score}/10."
