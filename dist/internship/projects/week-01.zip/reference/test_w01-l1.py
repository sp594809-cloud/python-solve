def discounted_total(price, quantity, discount):
    return round(price * quantity * (1 - discount / 100), 2)

assert discounted_total(20,3,10)==54
assert discounted_total(9,0,20)==0
assert discounted_total(12.5,2,20)==20
print("Checks passed")
