def greeting(name, score):
    return f"Hello {name.strip()}, your score is {score}/10."

assert greeting("Asha",8)=="Hello Asha, your score is 8/10."
assert greeting("  Krish  ",0)=="Hello Krish, your score is 0/10."
assert greeting("Sam",10).endswith("10/10.")
print("Checks passed")
