def celsius(fahrenheit_text):
    return round((float(fahrenheit_text) - 32) * 5 / 9, 2)

assert celsius("32")==0
assert celsius("212")==100
assert celsius("-40")==-40
print("Checks passed")
