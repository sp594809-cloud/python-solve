def celsius(fahrenheit_text):
    return round((float(fahrenheit_text) - 32) * 5 / 9, 2)
