def discounted_total(price, quantity, discount):
    return round(price * quantity * (1 - discount / 100), 2)
