def quiz(answers):
    questions=[("2 + 3", "5"),("Python file extension", ".py"),("Type of 3", "int")]
    score=0
    for (question,expected),answer in zip(questions,answers):
        if not answer.strip():
            raise ValueError("Answer must not be empty")
        score+=answer.strip().lower()==expected
    return score
if __name__=="__main__":
    print("Demo score:",quiz(["5",".py","int"]),"/3")
