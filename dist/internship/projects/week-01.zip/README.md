# Week 1: Quiz game

Explain expressions, types and text without copying code.

## Your assignment
- Write a three-question quiz with scoring.
- Reject an empty answer.
- Show a final score and explain how it is calculated.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Expressions and return values
Return the total price after a percentage discount.

Python evaluates arithmetic in an order. Parentheses make that order clear. Return sends a value to the caller; printing only displays it. A 10% discount keeps 90% of the original amount.

Try exercises/w01-l1.py before reading reference/w01-l1.py.

## Types and conversion
Convert numeric text into a Celsius temperature.

Input text is a string even when it looks like a number. float accepts decimals. Converting early separates input handling from arithmetic. Fahrenheit to Celsius is (F - 32) times 5/9.

Try exercises/w01-l2.py before reading reference/w01-l2.py.

## Text and readable output
Build a greeting from a name and integer score.

strip removes surrounding whitespace. An f-string inserts values into text without manual concatenation. Keep punctuation and spaces intentional because output is a user interface.

Try exercises/w01-l3.py before reading reference/w01-l3.py.
