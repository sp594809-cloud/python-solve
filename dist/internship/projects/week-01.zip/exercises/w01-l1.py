def discounted_total(price, quantity, discount):
    # TODO: implement the task. Keep the function name and parameters.
    pass
