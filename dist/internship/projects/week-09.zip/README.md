# Week 9: Responsive portfolio

Build an accessible page and add a small interaction.

## Your assignment
- Use semantic sections and a labelled form.
- Make a responsive card layout.
- Add an interactive button with keyboard support.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

Open index.html in your browser. Test keyboard navigation, two clicks, and narrow/wide windows. The contact form is demo only.

## Understand the page before styling it
Create an HTML page with main, h1 and a paragraph explaining your first Python project.

HTML describes the structure and meaning of a webpage. CSS controls appearance. JavaScript adds browser behaviour. Python usually runs on the server or in a special browser runtime such as this notebook.

Start with content people can read. A main landmark and a clear heading help navigation. Styling comes after the page has a sensible structure.

Try exercises/f09-l1.html before reading reference/f09-l1.html.

## Semantic HTML and accessible forms
Create a main section with a heading and a labelled email input.

HTML describes meaning. A label connected through for and id helps keyboard and screen-reader users. Use an actual button and an email input instead of clickable text.

Try exercises/w09-l1.html before reading reference/w09-l1.html.

## Responsive CSS with clear focus
Build two project cards in a responsive grid and a visible keyboard focus style.

A flexible grid avoids fixed phone widths. repeat(auto-fit, minmax(...)) adapts cards to space. A focus-visible outline shows a keyboard user where they are. Resize the preview on your laptop to review the layout.

Try exercises/w09-l2.html before reading reference/w09-l2.html.

## JavaScript and DOM events
Make a counter button increment the displayed count on every click.

Use addEventListener and textContent. The counter state is a number; displaying it is a separate step. Test two clicks and refresh. The structure checks below do not certify the behaviour; try it in the preview.

Try exercises/w09-l3.html before reading reference/w09-l3.html.

### Understand the page before styling it — walkthrough
- main identifies the principal page content.
- h1 names the page; p explains it.

Expected output: A heading and a paragraph

Common mistake: A paragraph styled with a large font is not automatically a heading. Use the element that matches the meaning.

Watch: [HTML and CSS](https://www.youtube.com/watch?v=zFZrkCIc2Oc) — Harvard CS50 · Brian Yu (English). Start with document structure, forms and selectors, then responsive layout.

Watch: [HTML and CSS](https://www.youtube.com/watch?v=zFZrkCIc2Oc) — Harvard CS50 · Brian Yu (English). Start with document structure, forms and selectors, then responsive layout.

Watch: [HTML and CSS](https://www.youtube.com/watch?v=zFZrkCIc2Oc) — Harvard CS50 · Brian Yu (English). Start with document structure, forms and selectors, then responsive layout.

Watch: [JavaScript](https://www.youtube.com/watch?v=x5trGVMKTdY) — Harvard CS50 · Brian Yu (English). Focus on DOM events, forms and API requests; test each interaction yourself.
