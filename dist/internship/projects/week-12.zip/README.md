# Week 12: Deployable web demo

Prepare a reproducible demo with sensible data and error boundaries.

## Your assignment
- Keep real secrets out of source and frontend code.
- Use sample data and document the demo limits.
- Deploy on a host you choose and test from another device.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run on a laptop (Python 3.11+)

```sh
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m unittest test_app.py
python -m uvicorn app:app --reload
```

Open http://127.0.0.1:8000 and /docs. Serve the frontend from this API; opening index.html directly will not make fetch work. Stop with Ctrl+C.

Local learning demo: no user accounts, persistent database, rate limits or production monitoring. Use only sample data. Do not expose private data or treat this as a production service.

Optional container: docker build -t study-demo . then docker run --rm -p 8000:8000 study-demo. Deployment depends on the host you select; configure its port, HTTPS and environment settings. Never commit real credentials.

## Separate a local demo from a deployable service
Define missing_settings(config) returning missing nonblank APP_MODE and DATABASE_URL keys in that order.

Deployment means running your program in another environment. That environment needs a start command, dependencies, configuration and a way to observe failures.

A local in-memory demo resets when the process restarts. Before calling it a persistent service, add an actual database and test restart behaviour. For this exercise use fake configuration values only.

Try exercises/f12-l1.py before reading reference/f12-l1.py.

## Read configuration with safe defaults
Accept only demo or production mode; missing or unknown values become demo.

Configuration changes between environments. A safe default keeps a demo predictable. Real server secrets must stay in environment variables on the server, never bundled into a static page or Git commit.

Try exercises/w12-l1.py before reading reference/w12-l1.py.

## Do not leak internals in errors
Return a public error containing a request ID, without including the exception text.

A server can log detailed failures internally while returning a generic message. Trace IDs let a developer investigate. Passwords, tokens, SQL and stack traces should not appear in public error responses.

Try exercises/w12-l2.py before reading reference/w12-l2.py.

## A reproducible health report
Report ready only when the database and model are both available.

A health endpoint should describe an actual dependency check. A static green badge cannot prove that the application works. A demo can use simple checks, but production needs timeouts, logs and operational monitoring.

Try exercises/w12-l3.py before reading reference/w12-l3.py.

### Separate a local demo from a deployable service — walkthrough
- Required configuration should be explicit.
- Check it early so a deployment fails with a useful explanation.

Expected output: 2

Common mistake: Putting a credential in frontend JavaScript exposes it to visitors. Keep server configuration on the server.

Watch: [Scalability and Security](https://www.youtube.com/watch?v=6PWTxRGh_dk) — Harvard CS50 · Brian Yu (English). Use the HTTPS and web-security discussion after you can run the local demo. Advanced scaling is optional.

Watch: [Scalability and Security](https://www.youtube.com/watch?v=6PWTxRGh_dk) — Harvard CS50 · Brian Yu (English). Use the HTTPS and web-security discussion after you can run the local demo. Advanced scaling is optional.

Watch: [Scalability and Security](https://www.youtube.com/watch?v=6PWTxRGh_dk) — Harvard CS50 · Brian Yu (English). Use the HTTPS and web-security discussion after you can run the local demo. Advanced scaling is optional.

Watch: [Scalability and Security](https://www.youtube.com/watch?v=6PWTxRGh_dk) — Harvard CS50 · Brian Yu (English). Use the HTTPS and web-security discussion after you can run the local demo. Advanced scaling is optional.
