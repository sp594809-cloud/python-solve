def missing_settings(config):
    pass
