def missing_settings(config):
    return [k for k in ("APP_MODE","DATABASE_URL") if not isinstance(config.get(k),str) or not config[k].strip()]
