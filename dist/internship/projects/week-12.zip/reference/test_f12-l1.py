def missing_settings(config):
    return [k for k in ("APP_MODE","DATABASE_URL") if not isinstance(config.get(k),str) or not config[k].strip()]

assert missing_settings({})==["APP_MODE","DATABASE_URL"]
assert missing_settings({"APP_MODE":"demo","DATABASE_URL":" "})==["DATABASE_URL"]
assert missing_settings({"APP_MODE":"demo","DATABASE_URL":"sqlite:///demo.db"})==[]
print("Checks passed")
