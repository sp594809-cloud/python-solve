# Week 7: Inventory manager

Build a small reusable package and validate API data.

## Your assignment
- Keep stock and prices in separate functions or classes.
- Reject negative quantities.
- Parse a supplied API response fixture.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Classes group state and behaviour
Create Counter with a value starting at 0 and an increment method adding 1.

A class defines a kind of object. An instance holds its own state. __init__ sets up that state when you create an instance. self refers to the current instance inside a method.

Use a class when data and behaviour belong together. A simple calculation may still be clearer as a function. Do not turn every function into a class automatically.

Try exercises/f07-l1.py before reading reference/f07-l1.py.

## Composition keeps objects understandable
Define Team with a members list supplied at creation; copy it and return its length from size().

Composition means building an object using other values or objects. A Team contains members. This often models a relationship more directly than inheritance.

When a caller owns a mutable list, decide whether your object shares it or copies it. Here the contract asks for a copy so later caller changes do not change the team.

Try exercises/f07-l2.py before reading reference/f07-l2.py.

## Read nested API data carefully
Define city(payload) returning payload["user"]["city"] or "Unknown" when user or city is missing. Assume user is a dictionary when present.

An API response often nests dictionaries and lists. Sketch the structure before writing the lookup. Validate types at the boundary, then navigate fields according to that contract.

This exercise uses a local fixture so it works without a live service. Real requests also need timeouts, status checks and handling for invalid JSON.

Try exercises/f07-l3.py before reading reference/f07-l3.py.

## Search a sequence and describe the cost
Define first_index(items,target), returning the first matching index or -1.

A linear search examines items from left to right. enumerate supplies both an index and value. Return as soon as you find the first match.

If there are n items, the worst case examines n items: O(n). This describes how work grows, not an exact number of seconds. Learn to explain this before memorizing algorithm names.

Try exercises/f07-l4.py before reading reference/f07-l4.py.

## Sort with a key without changing input
Define ranked(records), returning a new list sorted by score descending.

sorted returns a new list. A key function tells it which value to compare. lambda can express a small one-expression function at the point of use.

A list’s .sort method changes that list and returns None. Choose deliberately between an in-place operation and a returned result.

Try exercises/f07-l5.py before reading reference/f07-l5.py.

## Build a module with a clear interface
Define slug_words(text) as a reusable helper that strips whitespace, lowercases words and joins them with hyphens.

A module is a Python file with a focused purpose. Expose small functions with clear names and contracts. Keep interactive prompts in a separate CLI layer.

For a real laptop module, use an if __name__ == "__main__" guard around demonstration code. Importing a helper should not unexpectedly ask questions or start a server.

Try exercises/f07-l6.py before reading reference/f07-l6.py.

## Classes and state
Implement Cart with add(price), total(), and independent state per instance.

An object bundles state with behaviour. Put the list on self inside __init__; a class-level shared list would make different customers share a cart. Reject negative prices explicitly.

Try exercises/w07-l1.py before reading reference/w07-l1.py.

## Reusable modules
Return a slug containing lowercase words joined by hyphens.

Small pure helpers can move into their own module and be imported. split without an argument treats runs of whitespace as one separator. Join uses one separator between pieces, with no trailing separator.

Try exercises/w07-l2.py before reading reference/w07-l2.py.

## Validate an API response
Extract numeric Celsius values from an API fixture, ignoring incomplete entries.

An API can return missing or malformed data. Read optional fields with get and validate types before arithmetic. bool is a subclass of int in Python, so exclude booleans explicitly when expecting a measurement.

Try exercises/w07-l3.py before reading reference/w07-l3.py.

### Classes group state and behaviour — walkthrough
- Box(3) creates an instance and calls __init__.
- self.size stores a value on that instance.

Expected output: 3

Common mistake: Putting a shared mutable list on the class can share it across instances. Initialize per-object mutable state in __init__.

Watch: [Object-Oriented Programming](https://www.youtube.com/watch?v=e4fwY9ZsxPw) — Harvard CS50 · David Malan (English). Start with classes, instances and __init__. Save properties and inheritance for a second pass.

### Composition keeps objects understandable — walkthrough
- list(original) creates a separate list.
- Appending to the copy leaves the original length unchanged.

Expected output: 1

Common mistake: self.members=members shares the same list. That may be valid in another design, but it breaks this contract.

Watch: [Object-Oriented Programming](https://www.youtube.com/watch?v=e4fwY9ZsxPw) — Harvard CS50 · David Malan (English). Start with classes, instances and __init__. Save properties and inheritance for a second pass.

### Read nested API data carefully — walkthrough
- First select the user dictionary.
- Then select its name field.

Expected output: Asha

Common mistake: A fallback does not validate a wrong type. If user were a list, this code would need a separate validation rule.

Watch: [Libraries](https://www.youtube.com/watch?v=MztLZWibctI) — Harvard CS50 · David Malan (English). Follow imports, pip, JSON and the main-module pattern. Practise with the supplied local fixtures before live APIs.

### Search a sequence and describe the cost — walkthrough
- enumerate pairs positions with values.
- Indexes start at zero.

Expected output: 0 a
1 b

Common mistake: Returning -1 inside the loop gives up after the first non-match. Indentation changes the algorithm.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.

### Sort with a key without changing input — walkthrough
- The key reads each score.
- Ascending order puts the smaller score first.

Expected output: A

Common mistake: A long lambda is difficult to read. Use a named function when the decision needs multiple steps.

Watch: [Loops](https://www.youtube.com/watch?v=-7xg8pGcP6w) — Harvard CS50 · David Malan (English). Focus on for, while, lists and dictionaries; draw a short iteration trace.

### Build a module with a clear interface — walkthrough
- join combines strings with a separator.
- The helper returns a value the caller can reuse.

Expected output: study-notes

Common mistake: Do not call this a complete URL sanitizer. Real URLs need additional rules and validation.

Watch: [Libraries](https://www.youtube.com/watch?v=MztLZWibctI) — Harvard CS50 · David Malan (English). Follow imports, pip, JSON and the main-module pattern. Practise with the supplied local fixtures before live APIs.

Watch: [Object-Oriented Programming](https://www.youtube.com/watch?v=e4fwY9ZsxPw) — Harvard CS50 · David Malan (English). Start with classes, instances and __init__. Save properties and inheritance for a second pass.

Watch: [Object-Oriented Programming](https://www.youtube.com/watch?v=e4fwY9ZsxPw) — Harvard CS50 · David Malan (English). Start with classes, instances and __init__. Save properties and inheritance for a second pass.

Watch: [Object-Oriented Programming](https://www.youtube.com/watch?v=e4fwY9ZsxPw) — Harvard CS50 · David Malan (English). Start with classes, instances and __init__. Save properties and inheritance for a second pass.
