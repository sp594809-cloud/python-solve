# Week 7: Inventory manager

Build a small reusable package and validate API data.

## Your assignment
- Keep stock and prices in separate functions or classes.
- Reject negative quantities.
- Parse a supplied API response fixture.

The runnable demo is a starting point. Read it, rebuild one part without looking, add your own feature, and write a regression test. Submit a repository link and explanation in the course. Project review in the app is self-reported, not instructor verification.

## Run

```sh
python project.py
```

## Classes and state
Implement Cart with add(price), total(), and independent state per instance.

An object bundles state with behaviour. Put the list on self inside __init__; a class-level shared list would make different customers share a cart. Reject negative prices explicitly.

Try exercises/w07-l1.py before reading reference/w07-l1.py.

## Reusable modules
Return a slug containing lowercase words joined by hyphens.

Small pure helpers can move into their own module and be imported. split without an argument treats runs of whitespace as one separator. Join uses one separator between pieces, with no trailing separator.

Try exercises/w07-l2.py before reading reference/w07-l2.py.

## Validate an API response
Extract numeric Celsius values from an API fixture, ignoring incomplete entries.

An API can return missing or malformed data. Read optional fields with get and validate types before arithmetic. bool is a subclass of int in Python, so exclude booleans explicitly when expecting a measurement.

Try exercises/w07-l3.py before reading reference/w07-l3.py.
