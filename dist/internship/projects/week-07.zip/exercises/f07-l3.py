def city(payload):
    pass
