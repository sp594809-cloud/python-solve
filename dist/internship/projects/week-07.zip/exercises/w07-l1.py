class Cart:
    # TODO: implement the task. Keep the function name and parameters.
    pass
