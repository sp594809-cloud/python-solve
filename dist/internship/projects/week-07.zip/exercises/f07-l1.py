class Counter:
    def __init__(self):
        pass
    def increment(self):
        pass
