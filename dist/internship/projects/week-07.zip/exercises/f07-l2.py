class Team:
    def __init__(self, members):
        pass
    def size(self):
        pass
