def first_index(items, target):
    pass
