def ranked(records):
    pass
