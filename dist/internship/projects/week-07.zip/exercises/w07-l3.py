def temperatures(payload):
    # TODO: implement the task. Keep the function name and parameters.
    pass
