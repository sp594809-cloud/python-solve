def slug_words(text):
    pass
