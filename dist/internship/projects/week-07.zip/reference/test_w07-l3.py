def temperatures(payload):
    result = []
    for row in payload.get("readings", []):
        value = row.get("celsius")
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            result.append(value)
    return result

assert temperatures({"readings":[{"celsius":21},{},{"celsius":"warm"},{"celsius":True},{"celsius":0}]})==[21,0]
assert temperatures({})==[]
assert temperatures({"readings":[{"celsius":21.5}]})==[21.5]
print("Checks passed")
