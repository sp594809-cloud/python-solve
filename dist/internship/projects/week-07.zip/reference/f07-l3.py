def city(payload):
    return payload.get("user",{}).get("city","Unknown")
