class Cart:
    def __init__(self):
        self.prices = []
    def add(self, price):
        if price < 0:
            raise ValueError("price must be nonnegative")
        self.prices.append(price)
    def total(self):
        return sum(self.prices)
