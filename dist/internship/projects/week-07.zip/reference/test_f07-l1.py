class Counter:
    def __init__(self):
        self.value = 0
    def increment(self):
        self.value += 1

c=Counter();assert c.value==0
c=Counter();c.increment();assert c.value==1
a=Counter();b=Counter();a.increment();assert b.value==0
print("Checks passed")
