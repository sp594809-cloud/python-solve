def first_index(items, target):
    for i,value in enumerate(items):
        if value==target:
            return i
    return -1

assert first_index([3,5,3],3)==0
assert first_index([3,5],5)==1
assert first_index([],3)==-1 and first_index([1],2)==-1
print("Checks passed")
