def slug_words(text):
    return "-".join(text.lower().split())
