class Team:
    def __init__(self, members):
        self.members = list(members)
    def size(self):
        return len(self.members)

assert Team(["A","B"]).size()==2
assert Team([]).size()==0
a=["A"];t=Team(a);a.append("B");assert t.size()==1
print("Checks passed")
