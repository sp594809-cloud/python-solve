def slug_words(text):
    return "-".join(text.lower().split())

assert slug_words("  My Notes ")=="my-notes"
assert slug_words("")==""
assert slug_words("A   B")=="a-b"
print("Checks passed")
