class Team:
    def __init__(self, members):
        self.members = list(members)
    def size(self):
        return len(self.members)
