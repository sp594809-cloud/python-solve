def city(payload):
    return payload.get("user",{}).get("city","Unknown")

assert city({"user":{"city":"Ahmedabad"}})=="Ahmedabad"
assert city({})=="Unknown"
assert city({"user":{}})=="Unknown"
print("Checks passed")
