def temperatures(payload):
    result = []
    for row in payload.get("readings", []):
        value = row.get("celsius")
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            result.append(value)
    return result
