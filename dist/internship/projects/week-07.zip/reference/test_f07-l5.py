def ranked(records):
    return sorted(records,key=lambda r:r["score"],reverse=True)

assert [r["score"] for r in ranked([{"score":2},{"score":5}])]==[5,2]
assert ranked([])==[]
a=[{"score":2},{"score":5}];ranked(a);assert a[0]["score"]==2
print("Checks passed")
