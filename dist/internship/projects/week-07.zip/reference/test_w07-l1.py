class Cart:
    def __init__(self):
        self.prices = []
    def add(self, price):
        if price < 0:
            raise ValueError("price must be nonnegative")
        self.prices.append(price)
    def total(self):
        return sum(self.prices)

c=Cart(); c.add(2); c.add(3); assert c.total()==5
a=Cart(); b=Cart(); a.add(7); assert b.total()==0
c=Cart(); caught=False
try: c.add(-1)
except ValueError: caught=True
assert caught
print("Checks passed")
