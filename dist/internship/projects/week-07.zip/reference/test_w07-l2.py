def slug(text):
    return "-".join(text.lower().split())

assert slug("Python Course")=="python-course"
assert slug("  Build   apps ")=="build-apps"
assert slug("")==""
print("Checks passed")
