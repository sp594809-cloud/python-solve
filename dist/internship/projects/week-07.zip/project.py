class Inventory:
    def __init__(self):self.stock={}
    def add(self,name,quantity,price):
        if quantity<0 or price<0:raise ValueError("Negative stock or price")
        self.stock[name]={"quantity":quantity,"price":price}
    def value(self):return sum(v["quantity"]*v["price"] for v in self.stock.values())
def parse_stock(payload):return [(r["name"],r["quantity"],r["price"]) for r in payload.get("items",[])]
if __name__=="__main__":
    inventory=Inventory()
    for row in parse_stock({"items":[{"name":"pen","quantity":3,"price":10}]}):inventory.add(*row)
    print("Stock value:",inventory.value())
